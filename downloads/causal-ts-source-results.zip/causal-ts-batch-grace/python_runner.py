"""Warm in-process benchmarks of unmodified upstream public entry points."""
import contextlib
import json
import os
import sys
import time

import numpy as np
import pandas as pd
import torch
from causalts.cedar import run_cedar
from causalts.cdnots import run_cdnots, run_cdnots_plus
from causalts.ci_tests import ParCorrGPU

torch.set_num_threads(int(os.environ.get("BENCH_THREADS", "1")))
torch.set_num_interop_threads(1)


def convert(v):
    if isinstance(v, np.ndarray):
        return convert(v.tolist())
    if isinstance(v, np.generic):
        return convert(v.item())
    if isinstance(v, dict):
        return {k: convert(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [convert(x) for x in v]
    if isinstance(v, float) and not np.isfinite(v):
        return None
    return v


def execute(request):
    df = pd.read_csv(request["input"], float_precision="round_trip")
    algorithm = request["algorithm"]
    cfg = request["config"].copy()
    caching = request.get("caching", True)
    if algorithm == "cdnots+":
        cfg = cfg.pop("discovery") | cfg
    lag = cfg.pop("max_lag")
    if "include_c" in cfg:
        cfg["include_C"] = cfg.pop("include_c")
    def ci_factory(data):
        return ParCorrGPU(data, device="cpu", enable_caching=caching)
    if algorithm == "grace":
        from causalts.grace.gated_discovery import run_cdnots_gated

        cfg["model_seed"] = cfg.pop("seed")
        cfg |= cfg.pop("model", {})
        def run():
            return run_cdnots_gated(df, max_lag=lag, ci_test_class=ci_factory, device="cpu", verbose=False, **cfg)
    else:
        def run():
            ci = ci_factory(np.zeros((2, 2)))
            if algorithm == "cedar":
                return run_cedar(df, ci, max_lag=lag, n_jobs=1, verbose=False, **cfg)
            method = run_cdnots if algorithm == "cdnots" else run_cdnots_plus
            return method(df, ci, num_lags=lag, verbose=False, show_progress=False, **cfg)
    times = []
    with contextlib.redirect_stdout(sys.stderr):
        for _ in range(request["warmups"]):
            run()
        for _ in range(request["runs"]):
            result = None
            start = time.perf_counter_ns()
            result = run()
            times.append((time.perf_counter_ns() - start) / 1e6)
    output = {"graph": result.cg_tig, "var_names": result.var_names}
    if algorithm in ("cdnots", "cdnots+"):
        output |= {"marks": result.to_marks(), "endpoint_matrix": result.graph.G.graph,
                   "pvalue_matrix": result.pvalue_matrix, "n_test_records": len(result.pvals)}
    elif algorithm == "cedar":
        for field in ("n_tests", "selected_lags", "lag_importance", "lag_pvalues", "val_matrix", "pvalue_matrix", "ar_order"):
            if hasattr(result, field):
                output[field] = getattr(result, field)
    else:
        output |= {"gate_values": result.gate_values, "skeleton": result.skeleton, "lambda_l0": result.lambda_l0}
    return {"times_ms": times, "result": convert(output)}


for line in sys.stdin:
    try:
        result = execute(json.loads(line))
    except Exception:
        import traceback
        result = {"error": traceback.format_exc()}
    print(json.dumps(result, allow_nan=False), flush=True)
