# Causal-TS batch CI and GRACE follow-up

This compact download retains all source, tests, fixtures, raw measurements, reports and the current Linux CLI. Duplicate benchmark executables are omitted; rebuild them using `iteration2/build_benchmarks.py` and `iteration2/build_benchmarks.py --profiles`. Their original hashes are retained in `iteration2/provenance.json`.

Both requested tasks are complete. Start with [the current report](iteration2/REPORT.md) and [reproduction instructions](iteration2/REPRODUCE.md).

- Two queries over three columns in 512×1,024 data: 23.980151 ms → 0.022637 ms; requested allocation bytes 19,008,616 → 70,664.
- Discovery covariance gains retained, including 50.9× CDNOTS and 11.5× CDNOTS+ on 5,000×4 at lag two versus the original uncached source.
- One GRACE basis-projection change: backward 2.1–2.5× faster, backward allocation volume 30–32% lower, complete discovery 2.01–2.07× faster. Adam is unchanged.
- 104 CPU tests and 91 statistical-only tests pass. Identical-weight/noise prediction, gradient and update comparisons pass. CUDA/Metal hardware and feature builds were not run in this CPU-only environment.

`causal-ts-rs/` contains updated source, tests, the original-model neural golden fixture and a rebuilt Linux x86-64 CPU executable. `iteration2/` contains the new report, six CSV tables, raw outputs, plots, test logs, source snapshots, benchmark rebuild scripts, provenance hashes and profiling/reproduction scripts. `iteration2/source-changes.patch` covers text source/documentation changes; the new large JSON fixture is included directly rather than in that patch. No code comments were added.

Root `REPORT.md`, `REPRODUCE.md`, `environment.json` and `optimization/` retain earlier benchmark history. Their old source/binary hashes and statements about unchanged GRACE apply to those earlier stages. Current hashes are in `iteration2/provenance.json`; bundle checksums are in `BUNDLE-SHA256.json`.

The starting archive was `causal-ts-optimized-2026-10-24.zip`, SHA-256 `6fd7fb63fe14972ddaa76777e2fa66b1f4623ef224f3272a0e812c8d2ecde766`. The pinned upstream reference is Bloomberg Causal-TS `0d1fae061b2445a51d0c8b75fc565d897dd54fb7`. Project licenses and upstream notices are retained.
