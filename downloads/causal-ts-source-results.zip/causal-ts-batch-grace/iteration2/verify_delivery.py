import difflib
import hashlib
import json
from pathlib import Path
import re
import tomllib

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
source = ROOT / "causal-ts-rs"
baseline = HERE / "baseline-source"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(name):
    return json.loads((HERE / name).read_text())

provenance = load("provenance.json")
for path, expected in provenance["files_sha256"].items():
    assert sha(ROOT / path) == expected, path
old = (baseline / "src/grace/model.rs").read_text()
new = (source / "src/grace/model.rs").read_text()
start = "        } else if self.config.basis_expansion {"
end = "        } else {"

def without_basis(text):
    left = text.index(start, text.index("    pub fn forward("))
    right = text.index(end, left + len(start))
    return text[:left] + text[right:]

assert without_basis(old) == without_basis(new), "GRACE change exceeds basis projection"
assert old[old.index("pub struct Adam"):] == new[new.index("pub struct Adam"):]
assert (source / "Cargo.lock").read_bytes() == (baseline / "Cargo.lock").read_bytes()
old_manifest = tomllib.loads((baseline / "Cargo.toml").read_text())
new_manifest = tomllib.loads((source / "Cargo.toml").read_text())
for key in ("dependencies", "features", "profile"):
    assert old_manifest[key] == new_manifest[key], key
for path in source.rglob("*.rs"):
    relative = path.relative_to(source)
    if relative.parts[0] not in ("src", "tests", "examples"):
        continue
    previous = baseline / relative
    before = previous.read_text().splitlines() if previous.exists() else []
    changes = difflib.ndiff(before, path.read_text().splitlines())
    assert not any(line.startswith("+ ") and re.match(r"\s*(//|/\*)", line[2:]) for line in changes), f"added comment in {relative}"
for name, expected in (("task2-cpu-tests.log", 104), ("task2-core-tests.log", 91), ("task2-final-strided-parity.log", 2), ("task2-baseline-strided-parity.log", 2)):
    log = (HERE / name).read_text()
    passed = sum(map(int, re.findall(r"test result: ok\. (\d+) passed", log)))
    assert passed == expected, (name, passed)
    assert "test result: FAILED" not in log
for name in ("task1-batch-summary.json", "task1-discovery-summary.json"):
    for row in load(name):
        assert row["maximum_numeric_difference"] <= 1e-9
for row in load("task2-discovery-summary.json"):
    assert row["parity"]["graphs_exact"] and row["parity"]["skeleton_exact"] and row["parity"]["epochs_exact"]
for revision, model in (("before", baseline / "src/grace/model.rs"), ("candidate1", source / "src/grace/model.rs")):
    for variables in (4, 8):
        a = load(f"task2-results/{revision}_{variables}vars_alloc.json")
        b = load(f"task2-results/{revision}_{variables}vars_ops.json")
        assert a["model_sha256"] == b["model_sha256"] == sha(model)
        assert a["final_state"] == b["final_state"]
for manifest in (source / "SHA256SUMS", source / "prebuilt/linux-x86_64/SHA256SUMS"):
    for line in manifest.read_text().splitlines():
        expected, path = line.split("  ", 1)
        assert sha(manifest.parent / path) == expected, path
print("Delivery verified: hashes, unchanged Adam/loss/gates/features, no added Rust comments, tests and result/profile parity.")
