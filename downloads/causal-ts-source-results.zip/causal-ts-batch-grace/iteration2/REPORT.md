# Batch CI and GRACE optimization — 2026-10-24

Both tasks passed. The required two-query batch falls from **23.980151 ms to 0.022637 ms**, with requested allocation volume falling from **19,008,616 to 70,664 bytes**. The discovery covariance cache retains its gains. One GRACE projection change cuts backward time by **2.1–2.5×**, backward allocation volume by **30–32%**, and complete discovery time by **2.01–2.07×** across the three measured workloads.

The starting point is `causal-ts-optimized-2026-10-24.zip`, SHA-256 `6fd7fb63fe14972ddaa76777e2fa66b1f4623ef224f3272a0e812c8d2ecde766`. Task 1 passed its CPU suite and result comparisons before Task 2 began; see [the completion record](task1-passed.json). Source changes are in [src/ci.rs](../causal-ts-rs/src/ci.rs) and [src/grace/model.rs](../causal-ts-rs/src/grace/model.rs). No code comments were added.

## Task 1: query-scoped covariance

`batch_test` validates and canonicalizes the queries, identifies their used columns, and prepares covariance only for the union of eligible complete queries. It borrows the selected data. Batches smaller than four, insufficient samples, GCMI, fewer than four reusable queries, or a poor estimated amortization use scalar testing. The estimate compares the sum of `width * (width + 8)` over eligible queries with twice that work for their union. This is a conservative planning heuristic, not a timing oracle.

Queries with missing values retain their own complete-row selection. The existing ill-conditioned/singular fallback, validation and result order are preserved. Discovery still prepares its immutable data-window cache. New regressions cover nonconsecutive indices, unused missing columns, repeated and disjoint queries, empty/small batches, mixed complete/missing columns, singular/constant inputs and invalid indices. The seven prepared-CI tests compare every result field against scalar testing.

### Required sparse-column benchmark

All cases use 512 rows and 1,024 input columns. `two` uses `(7, 511 | 1023)` and `(1023, 7)`; `repeated` repeats these queries 128 times; `disjoint` uses 32 different three-column subsets. Three warmups and 21 measured calls per configuration; allocation counts come from a separate call after timing. Input generation is excluded. Before is the supplied archive; after is the Task 1 implementation.

| Pattern | Queries | Before ms | After ms | Speedup | Allocated bytes before → after | Allocation calls before → after |
| --- | --- | --- | --- | --- | --- | --- |
| two | 2 | 23.980151 | 0.022637 | 1059.3× | 19,008,616 → 70,664 | 23 → 39 |
| repeated | 128 | 23.924571 | 0.097472 | 245.5× | 19,047,856 → 98,049 | 744 → 1156 |
| disjoint | 32 | 23.620303 | 0.476512 | 49.6× | 19,022,000 → 1,462,752 | 344 → 742 |

For the required two queries, the new batch call uses scalar testing. Direct sequential scalar execution measured 0.018830 ms. An explicitly prepared three-column context measured 0.012571 ms, but that diagnostic excludes batch planning, index remapping and Rayon collection; it is not the public batch path. For 128 repeated queries, direct scalar execution was 1.186162 ms versus the new batch's 0.097472 ms. The disjoint case correctly avoids covariance preparation and measured 0.476512 ms versus 0.443544 ms for direct sequential scalar execution.

Maximum absolute cached/scalar difference across these benchmarks was `2.22e-16`; statuses, sample counts, conditioning sizes and result order agree. The required case's process peak RSS fell from 24,424 to 5,936 KiB. The number of allocation calls rises slightly while the allocated byte volume falls sharply. See [raw batch data](task1-batch-summary.json) and [CSV](task1-batch.csv).

### Discovery cache gains retained

Each version has two warmups and 11 measured calls. All 14 complete output objects retain exact discrete fields; maximum absolute floating-point difference is `2.41e-12`. `Original` is the implementation before covariance reuse, `Supplied` is the requested archive, and `Fixed` is Task 1. Cache construction is inside the timed discovery call.

| Case | Original ms | Supplied ms | Fixed ms | Original / fixed |
| --- | --- | --- | --- | --- |
| fixture_300x4_L2_cdnots | 1.6914 | 0.3841 | 0.3663 | 4.62× |
| fixture_300x4_L2_cdnotsplus | 0.5919 | 0.1836 | 0.1924 | 3.08× |
| chain_1000x4_L2_cdnots | 11.8981 | 0.8640 | 0.9282 | 12.82× |
| chain_1000x4_L2_cdnotsplus | 2.1762 | 0.3068 | 0.3185 | 6.83× |
| chain_5000x4_L2_cdnots | 68.7561 | 1.3395 | 1.3502 | 50.92× |
| chain_5000x4_L2_cdnotsplus | 12.1776 | 1.0492 | 1.0611 | 11.48× |
| chain_1000x8_L2_cdnots | 61.3933 | 4.2746 | 4.1172 | 14.91× |
| chain_1000x8_L2_cdnotsplus | 8.3014 | 0.9723 | 1.0445 | 7.95× |
| chain_1000x8_L5_cdnots | 237.3559 | 16.7425 | 17.0249 | 13.94× |
| chain_1000x8_L5_cdnotsplus | 14.6062 | 2.4012 | 2.3565 | 6.20× |
| chain_1000x16_L2_cdnots | 470.1189 | 38.3664 | 38.1575 | 12.32× |
| chain_1000x16_L2_cdnotsplus | 28.9486 | 3.3754 | 3.3303 | 8.69× |
| nonstationary_L1_cdnots | 0.1244 | 0.0494 | 0.0510 | 2.44× |
| nonstationary_L1_cdnotsplus | 6.2619 | 6.3595 | 6.3687 | 0.98× |

The nonstationary CDNOTS+ case did not benefit from the earlier covariance optimization and remains approximately unchanged. Timing ranges and RSS for every case are retained in [JSON](task1-discovery-summary.json) and [CSV](task1-discovery.csv).

## Task 2: one measured cause

An isolated Candle 0.11.0 profiler times graph sorting and individual backward nodes, recording the operation, tensor shapes and allocation deltas. The production dependency is unchanged; no Candle fork is used by the delivered library. A separate unpatched pass measures whole-phase allocations, and the existing clean phase profiler supplies the headline times. The operation and unpatched allocation runs finish with exactly identical parameter states for both four and eight variables, before and after.

The largest cost was the basis encoder's `[batch, variables, lags, 3, hidden]` broadcast product and its gradient reductions. The following are mean instrumented backward costs per step, batch 128, three lag slots, hidden width 64. The broadcast node's time is its backward reduction, not the cheap forward view.

| Variables | Backward node | Instrumented ms | Requested allocation bytes |
| --- | --- | --- | --- |
| 4 | BinaryMul | 1.3988 | 7,080,000 |
| 4 | Broadcast | 1.1622 | 29,096 |
| 4 | ReduceSum | 0.4085 | 2,360,288 |
| 4 | Total for these three nodes | 2.9694 | 9,469,384 |
| 8 | BinaryMul | 2.6984 | 14,157,888 |
| 8 | Broadcast | 2.1933 | 56,744 |
| 8 | ReduceSum | 0.5916 | 4,719,584 |
| 8 | Total for these three nodes | 5.4833 | 18,934,216 |

On eight variables these three nodes account for 5.4833 ms of 9.5248 ms attributed to backward nodes (57.6%), including 18,934,216 requested bytes. The multiplication materializes large gradient tensors; the broadcast gradient reduces across the batch, and the sum gradient expands the basis dimension.

The only production GRACE change replaces `stack([x, x², abs(x)]) * W`, summed across the three basis terms, with a batched matrix multiplication. Inputs are arranged as `[variables * lags, batch, 3]`, weights as `[variables * lags, 3, hidden]`, and the output is restored to the existing layout before adding the same bias. This removes the expanded product while retaining the mathematical projection. Model dimensions, parameter names/layouts, loss, gate noise, gradients and Adam behavior remain covered by reference tests. Loss, gate and Adam source bodies are unchanged. Linear and nonlinear encoder paths are unchanged. No subsequent optimization was mixed into the measured candidate.

### Supplied phase profiles repeated

Times are milliseconds per training step, median of seven independently reset block means. Every block has ten warmup and 40 measured steps. Rust and PyTorch use the same exported initial weights, skeleton, model settings and first 128 normalized lag windows. Each uses its native random gate stream during timing; the numerical parity tests separately use identical explicit noise. Phase medians need not sum exactly to the independently calculated total median.

| Case | Version | Forward | Loss | Backward | Adam | Other | Total |
| --- | --- | --- | --- | --- | --- | --- | --- |
| fixture_300x4_L2 | Before | 1.8238 | 0.0127 | 4.6577 | 0.1904 | 0.1000 | 6.7961 |
| fixture_300x4_L2 | After | 0.6728 | 0.0119 | 1.8920 | 0.1817 | 0.0387 | 2.7957 |
| fixture_300x4_L2 | PyTorch | 0.8527 | 0.1671 | 1.2145 | 0.7122 | 0.0750 | 3.0128 |
| chain_1000x4_L2 | Before | 1.8061 | 0.0129 | 4.6218 | 0.1885 | 0.0983 | 6.7275 |
| chain_1000x4_L2 | After | 0.6598 | 0.0122 | 1.8839 | 0.1820 | 0.0367 | 2.7753 |
| chain_1000x4_L2 | PyTorch | 0.8420 | 0.1650 | 1.2109 | 0.6973 | 0.0760 | 2.9808 |
| chain_1000x8_L2 | Before | 3.6085 | 0.0172 | 8.6569 | 0.3816 | 0.0651 | 12.7176 |
| chain_1000x8_L2 | After | 1.3256 | 0.0165 | 4.0278 | 0.3573 | 0.0637 | 5.7987 |
| chain_1000x8_L2 | PyTorch | 1.4286 | 0.1783 | 2.1830 | 1.1613 | 0.1011 | 5.0311 |

Forward improves by about 2.7× and backward by 2.1–2.5×. Backward remains a large share because forward improved too. It is still about 1.55–1.85× slower than PyTorch's backward on these CPU workloads; this change does not eliminate every gap. Adam was not changed. See [phase CSV](task2-phases.csv) and the before/after/Python phase summary JSON files.

### Allocation measurements

These are mean requested CPU heap bytes per step, with ten warmups and 20 measured steps on the 1,000-row shared profile inputs. Counters wrap successful `alloc`, `alloc_zeroed` and `realloc` calls; realloc counts the requested new size. Freed bytes are not subtracted. These numbers measure allocation traffic, **not peak or live memory**. Atomics add overhead, so these runs are not used for headline timings. Per-operation records exclude their own label formatting; whole-phase totals come from the unpatched allocator-only pass.

| Variables | Phase | Before bytes | After bytes | Byte reduction | Allocation calls before → after |
| --- | --- | --- | --- | --- | --- |
| 4 | forward | 3,903,702 | 2,741,767 | 29.8% | 800 → 803 |
| 4 | loss | 22,068 | 22,068 | 0.0% | 93 → 93 |
| 4 | backward | 26,409,287 | 17,880,365 | 32.3% | 3514 → 3525 |
| 4 | adam | 2,640,702 | 2,640,702 | 0.0% | 2484 → 2484 |
| 8 | forward | 7,796,210 | 5,473,107 | 29.8% | 1345 → 1360 |
| 8 | loss | 40,180 | 40,180 | 0.0% | 93 → 93 |
| 8 | backward | 55,862,848 | 38,807,602 | 30.5% | 5884 → 5943 |
| 8 | adam | 5,272,846 | 5,272,846 | 0.0% | 4692 → 4692 |

Backward allocation counts rise slightly while byte volume falls. Adam bytes and allocation counts are exactly unchanged. The remaining eight-variable operation costs are spread among bias broadcast reductions (~0.72 ms), gate aggregation matmul (~0.56 ms), decoder slices (~0.52 ms), decoder matmuls (~0.51 ms) and decoder bias reductions (~0.49 ms), measured with operation instrumentation. All operations and shapes are retained in [CSV](task2-operations.csv); whole-phase values are in [allocation CSV](task2-allocations.csv).

### Complete GRACE discovery

Thirty epochs, patience 31, batch size 128, seed 42, maximum lag two, C included. Two warmups and seven measured discovery calls for each implementation, in seeded randomized order. Includes skeleton discovery, preprocessing, training and graph extraction. CSV parsing, process startup, imports and serialization are outside algorithm timing. Python is unmodified Bloomberg Causal-TS at `0d1fae061b2445a51d0c8b75fc565d897dd54fb7`. Before contains the passed Task 1 fix and the original GRACE model; after adds only the basis projection change.

| Dataset | Rust before ms | Rust after ms | Python ms | Before / after | Python / after |
| --- | --- | --- | --- | --- | --- |
| fixture_300x4_L2 | 500.476 | 248.611 | 434.863 | 2.01× | 1.75× |
| chain_1000x4_L2 | 1725.461 | 832.601 | 1163.393 | 2.07× | 1.40× |
| chain_1000x8_L2 | 3467.710 | 1704.674 | 1800.198 | 2.03× | 1.06× |

All final graphs match before/after and Python for these three cases. Native skeletons, selected lambda and epoch counts are exact. Maximum native gate difference is `5.96e-8`; maximum loss-history difference is `1.03e-7`. Equal final graphs on these cases do not establish equal training trajectories across unrelated Rust/Python RNG streams.

Process peak RSS drops from 17,728 to 10,956 KiB (300×4), 18,216 to 11,608 KiB (1,000×4), and 30,032 to 17,812 KiB (1,000×8). RSS includes the entire process, unlike allocation traffic. All samples, ranges, RSS and full results are in [discovery JSON](task2-discovery-summary.json), [CSV](task2-discovery.csv) and [raw results](task2-results/).

![GRACE discovery timing and backward allocation volume](grace-results.png)

## Correctness and backend checks

- **104 CPU tests passed**, including all ten existing neural/tensor reference tests, seven prepared-CI tests and two new GRACE batch tests. **91 statistical-only tests passed**. Strict Clippy and formatting passed.
- The new golden fixture was generated from the original supplied GRACE source before the change. Six cases cover four/eight variables, batches 1/13/128, contiguous and genuinely strided inputs, and two updates with identical transferred weights, skeletons and explicit gate noise. Both old and new models pass the fixture. Maximum errors: predictions `3.58e-7`, loss `2.39e-7`, all parameter/input gradients `3.34e-6`, updated parameters `1.87e-6`. Tests use absolute plus relative tolerances: `2e-5 + 2e-5*abs(reference)` for predictions/loss/updates; `5e-5 + 2e-5*abs(reference)` for gradients. Existing upstream fixture tolerances were not changed.
- Production CUDA/Metal feature flags and dependencies remain unchanged. The replacement uses standard portable Candle reshape/permute/contiguous/matmul/broadcast operations. **No CUDA or Metal hardware test or feature build ran**: this Linux environment has neither CUDA hardware/toolkit nor Apple hardware/SDK. Both opt-in GPU tests remain ignored. The CPU test for explicit unavailable-device errors passed.

Evidence: [CPU suite](task2-cpu-tests.log), [statistical suite](task2-core-tests.log), [original-model layout parity](task2-baseline-strided-parity.log), [optimized layout parity](task2-final-strided-parity.log), [Clippy](final-clippy.log), [formatting](final-fmt.log).

## Method and reproduction

Linux x86-64, Intel Xeon Platinum 8573C, Rust 1.99.1, Python 3.12.14, PyTorch 2.14.1+cpu, Candle 0.11.0. Release builds use thin LTO, one codegen unit and the default CPU target. Timing workers run sequentially, pinned to CPU 0 with one computation thread. No build was run concurrently with timing. Measurements are workload-specific; sample ranges are available rather than inferred confidence intervals.

Use [REPRODUCE.md](REPRODUCE.md). Separate Cargo target directories are required for separate source snapshots. An initial baseline batch build accidentally reused a current-source artifact; it was discarded, rebuilt in its own target directory and all batch measurements were repeated. Only the corrected batch measurements appear here and in `task1-results/`. The supplied source snapshot, Task 1 snapshot, original pre-covariance snapshot, model hashes and measured binary hashes are included. Allocation instrumentation is isolated from the production dependency graph.
