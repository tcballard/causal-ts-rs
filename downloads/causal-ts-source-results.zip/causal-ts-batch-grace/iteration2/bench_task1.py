import json
import math
import os
from pathlib import Path
import random
import statistics
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUT = HERE / "task1-results"
OUT.mkdir(exist_ok=True)
env = os.environ.copy()
env.update({k: "1" for k in ("BENCH_THREADS", "RAYON_NUM_THREADS", "OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")})

def compare(a, b):
    maximum = 0.0
    def visit(x, y):
        nonlocal maximum
        if isinstance(x, float) or isinstance(y, float):
            assert isinstance(x, (int, float)) and isinstance(y, (int, float))
            delta = abs(x-y)
            assert math.isfinite(delta) and delta <= 1e-9, (x, y)
            maximum = max(maximum, delta)
        elif isinstance(x, dict):
            assert x.keys() == y.keys()
            for key in x:
                visit(x[key], y[key])
        elif isinstance(x, list):
            assert len(x) == len(y)
            for left, right in zip(x, y):
                visit(left, right)
        else:
            assert x == y, (x, y)
    visit(a, b)
    return maximum

def run(name, command, request=None):
    stem = OUT / name
    with stem.with_suffix(".json").open("w") as stdout, stem.with_suffix(".log").open("w") as stderr:
        subprocess.run([str(ROOT / "measure_process"), str(stem.with_suffix(".rss")), "taskset", "-c", "0", *map(str, command)],
            input=None if request is None else json.dumps(request)+"\n", text=True, stdout=stdout, stderr=stderr, env=env, check=True, timeout=180)
    data = json.loads(stem.with_suffix(".json").read_text())
    assert "error" not in data, data.get("error")
    data["median_ms"] = statistics.median(data["times_ms"])
    data["min_ms"] = min(data["times_ms"])
    data["max_ms"] = max(data["times_ms"])
    data["peak_rss_kib"] = int(stem.with_suffix(".rss").read_text())
    return data

rng = random.Random(42)
batches = []
for pattern in ("two", "repeated", "disjoint"):
    implementations = [("before", "batch"), ("after", "batch"), ("after", "scalar")]
    if pattern != "disjoint":
        implementations.append(("after", "selected"))
    rng.shuffle(implementations)
    record = {"pattern": pattern, "implementations": {}}
    results = {}
    for revision, mode in implementations:
        name = f"{revision}_{mode}"
        output = run(f"batch_{pattern}_{name}", [HERE / f"task1-{revision}-batch", mode, pattern, "21"])
        results[name] = output.pop("result")
        record["implementations"][name] = output
    record["maximum_numeric_difference"] = max(compare(results["after_scalar"], v) for v in results.values())
    batches.append(record)
    print("BATCH", pattern, {k: {f: round(v[f], 6) for f in ("median_ms", "allocation_calls", "allocated_bytes", "peak_rss_kib")} for k, v in record["implementations"].items()}, flush=True)
    (HERE / "task1-batch-summary.json").write_text(json.dumps(batches, indent=2)+"\n")

if "--batch-only" in sys.argv:
    print("TASK 1 BATCH MEASUREMENTS AND RESULT CHECKS PASSED", flush=True)
    raise SystemExit(0)

discovery = []
commands = {"original": ROOT / "optimization/baseline-compare", "supplied": HERE / "task1-before-compare", "fixed": HERE / "task1-after-compare"}
for case in json.loads((ROOT / "cases.json").read_text()):
    if case["algorithm"] not in ("cdnots", "cdnots+"):
        continue
    request = {k: case[k] for k in ("algorithm", "input", "config")}
    request["input"] = str(ROOT / Path(request["input"]).relative_to("/workspace/causal-benchmark"))
    request.update(runs=11, warmups=2)
    order = list(commands)
    rng.shuffle(order)
    record = {"case": case, "implementations": {}}
    results = {}
    for implementation in order:
        output = run(f"{case['id']}_{implementation}", [commands[implementation]], request)
        results[implementation] = output.pop("result")
        record["implementations"][implementation] = output
    record["maximum_numeric_difference"] = max(compare(results["fixed"], v) for v in results.values())
    record["speedup_vs_original"] = record["implementations"]["original"]["median_ms"] / record["implementations"]["fixed"]["median_ms"]
    record["speedup_vs_supplied"] = record["implementations"]["supplied"]["median_ms"] / record["implementations"]["fixed"]["median_ms"]
    discovery.append(record)
    print("DISCOVERY", case["id"], {k: round(v["median_ms"], 4) for k, v in record["implementations"].items()}, "speedup", round(record["speedup_vs_original"], 2), flush=True)
    (HERE / "task1-discovery-summary.json").write_text(json.dumps(discovery, indent=2)+"\n")
print("TASK 1 BENCHMARK AND RESULT CHECKS PASSED", flush=True)
