import argparse
from pathlib import Path
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
parser = argparse.ArgumentParser()
parser.add_argument("--profiles", action="store_true")
parser.add_argument("--offline", action="store_true")
args = parser.parse_args()

def run(command):
    print(" ".join(map(str, command)), flush=True)
    subprocess.run(list(map(str, command)), cwd=ROOT, check=True)

def build(source, target, examples, locked=True, extra=()):
    command = ["cargo", "build", "--manifest-path", source / "Cargo.toml", "--target-dir", target, "--release"]
    if locked:
        command.append("--locked")
    if args.offline:
        command.append("--offline")
    for example in examples:
        command += ["--example", example]
    run(command + list(extra))

def save(target, example, name):
    shutil.copy2(target / "release/examples" / example, HERE / name)

if not args.profiles:
    plans = [
        (ROOT / "optimization/baseline-source", "original", ("compare",)),
        (HERE / "baseline-source", "supplied", ("compare", "bench_ci_batch")),
        (HERE / "task1-source", "task1", ("compare", "bench_ci_batch", "profile_grace")),
        (ROOT / "causal-ts-rs", "final", ("compare", "bench_ci_batch", "profile_grace")),
    ]
    targets = {}
    for source, name, examples in plans:
        target = HERE / "build" / name
        targets[name] = target
        build(source, target, examples)
    shutil.copy2(targets["original"] / "release/examples/compare", ROOT / "optimization/baseline-compare")
    for example, name in (("compare", "task1-before-compare"), ("bench_ci_batch", "task1-before-batch")):
        save(targets["supplied"], example, name)
    for example, name in (("compare", "task1-after-compare"), ("compare", "task2-before-compare"), ("bench_ci_batch", "task1-after-batch"), ("profile_grace", "task2-before-profile")):
        save(targets["task1"], example, name)
    for example, name in (("compare", "task2-candidate1-compare"), ("profile_grace", "task2-candidate1-profile")):
        save(targets["final"], example, name)
else:
    for revision, source in (("before", HERE / "grace-baseline.rs"), ("candidate1", ROOT / "causal-ts-rs/src/grace/model.rs")):
        run([sys.executable, HERE / "prepare_profiler.py", "--model-source", source])
        for mode in ("alloc", "ops"):
            target = HERE / "build" / f"profiler-{revision}-{mode}"
            extra = [] if mode == "alloc" else ["--features", "operations", "--config", f'patch.crates-io.candle-core.path="{HERE / "candle-instrumented"}"']
            build(HERE / "profiler", target, (), locked=False, extra=extra)
            shutil.copy2(target / "release/causal-ts-profile", HERE / f"task2-{revision}-{mode}")
print("Benchmark binaries ready.")
