use crate::{op::Op, Tensor};
use std::{
    sync::{
        atomic::{AtomicBool, Ordering},
        Mutex,
    },
    time::Instant,
};

extern "C" {
    fn candle_profile_allocation_calls() -> u64;
    fn candle_profile_allocated_bytes() -> u64;
}

static ENABLED: AtomicBool = AtomicBool::new(false);
static EVENTS: Mutex<Vec<Event>> = Mutex::new(Vec::new());

pub struct Event {
    pub operation: String,
    pub nanoseconds: u64,
    pub allocation_calls: u64,
    pub allocated_bytes: u64,
}

pub fn start() {
    let mut events = EVENTS.lock().unwrap();
    events.clear();
    events.reserve(1024);
    ENABLED.store(true, Ordering::Relaxed);
}

pub fn finish() -> Vec<Event> {
    ENABLED.store(false, Ordering::Relaxed);
    std::mem::take(&mut EVENTS.lock().unwrap())
}

pub struct Guard {
    operation: String,
    start: Instant,
    calls: u64,
    bytes: u64,
}

pub fn label(operation: String) -> Option<Guard> {
    if !ENABLED.load(Ordering::Relaxed) {
        return None;
    }
    Some(Guard {
        operation,
        calls: unsafe { candle_profile_allocation_calls() },
        bytes: unsafe { candle_profile_allocated_bytes() },
        start: Instant::now(),
    })
}

pub fn scope(op: &Op, node: &Tensor) -> Option<Guard> {
    if !ENABLED.load(Ordering::Relaxed) {
        return None;
    }
    let name = match op {
        Op::Binary(_, _, op) => format!("Binary{op:?}"),
        Op::Unary(_, op) => format!("Unary{op:?}"),
        Op::Reduce(arg, op, _) => format!("Reduce{op:?} {:?} ->", arg.dims()),
        Op::Broadcast(arg) => format!("Broadcast {:?} ->", arg.dims()),
        Op::Matmul(lhs, rhs) => format!("Matmul {:?} x {:?} ->", lhs.dims(), rhs.dims()),
        Op::Reshape(arg) => format!("Reshape {:?} ->", arg.dims()),
        Op::Transpose(_, _, _) => "Transpose".into(),
        Op::Permute(_, _) => "Permute".into(),
        Op::Narrow(arg, _, _, _) => format!("Narrow {:?} ->", arg.dims()),
        Op::Cat(_, _) => "Cat".into(),
        Op::Copy(_) => "Copy".into(),
        Op::Affine { .. } => "Affine".into(),
        Op::WhereCond(_, _, _) => "WhereCond".into(),
        Op::CustomOp1(_, op) => format!("CustomOp1 {}", op.name()),
        Op::CustomOp2(_, _, op) => format!("CustomOp2 {}", op.name()),
        _ => "Other".into(),
    };
    label(format!("{name} {:?}", node.dims()))
}

impl Drop for Guard {
    fn drop(&mut self) {
        let nanoseconds = self.start.elapsed().as_nanos() as u64;
        let allocation_calls = unsafe { candle_profile_allocation_calls() } - self.calls;
        let allocated_bytes = unsafe { candle_profile_allocated_bytes() } - self.bytes;
        EVENTS.lock().unwrap().push(Event {
            operation: std::mem::take(&mut self.operation),
            nanoseconds,
            allocation_calls,
            allocated_bytes,
        });
    }
}
