import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
parser = argparse.ArgumentParser()
parser.add_argument("--base-archive", type=Path, required=True)
parser.add_argument("--destination", type=Path, required=True)
args = parser.parse_args()
staging = HERE / "delivery"
staging.mkdir(exist_ok=True)
bundle = staging / "causal-ts-batch-grace"
bundle.mkdir(exist_ok=True)

def copy(path, relative):
    target = bundle / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, target)

with zipfile.ZipFile(args.base_archive) as archive:
    prefix = "causal-ts-optimized/"
    for entry in archive.infolist():
        if entry.is_dir():
            continue
        assert entry.filename.startswith(prefix)
        relative = Path(entry.filename.removeprefix(prefix))
        assert ".." not in relative.parts
        target = bundle / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(archive.read(entry))
        mode = entry.external_attr >> 16
        if mode:
            target.chmod(mode & 0o777)

source = ROOT / "causal-ts-rs"
for name in ("python_runner.py", "measure_process", "measure_process.c"):
    copy(ROOT / name, Path(name))
for path in source.rglob("*"):
    if path.is_file() and "target" not in path.relative_to(source).parts:
        copy(path, Path("causal-ts-rs") / path.relative_to(source))

exclude = {"task1-benchmark.log", "task1-baseline-build.log", "task1-baseline-build-final.log", "task1-baseline-clean.log"}
for path in HERE.iterdir():
    if path.is_file() and path.name not in exclude:
        copy(path, Path("iteration2") / path.name)
for name in ("task1-results", "task2-results", "smoke", "task1-source"):
    for path in (HERE / name).rglob("*"):
        if path.is_file() and "target" not in path.relative_to(HERE / name).parts:
            copy(path, Path("iteration2") / path.relative_to(HERE))
for path in (HERE / "profiler").rglob("*"):
    if path.is_file() and path.name != "model_source.rs" and "target" not in path.relative_to(HERE / "profiler").parts:
        copy(path, Path("iteration2") / path.relative_to(HERE))
with zipfile.ZipFile(args.base_archive) as archive:
    prefix = "causal-ts-optimized/causal-ts-rs/"
    for entry in archive.infolist():
        if entry.is_dir() or not entry.filename.startswith(prefix):
            continue
        relative = Path(entry.filename.removeprefix(prefix))
        if relative.parts[0] not in ("src", "tests", "examples") and str(relative) not in ("Cargo.toml", "Cargo.lock", "LICENSE", "UPSTREAM-NOTICE"):
            continue
        target = bundle / "iteration2/baseline-source" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(archive.read(entry))
for name in ("examples/bench_ci_batch.rs", "examples/support/allocations.rs"):
    copy(source / name, Path("iteration2/baseline-source") / name)

(bundle / "README.md").write_text("""# Causal-TS batch CI and GRACE follow-up

Both requested tasks are complete. Start with [the current report](iteration2/REPORT.md) and [reproduction instructions](iteration2/REPRODUCE.md).

- Two queries over three columns in 512×1,024 data: 23.980151 ms → 0.022637 ms; requested allocation bytes 19,008,616 → 70,664.
- Discovery covariance gains retained, including 50.9× CDNOTS and 11.5× CDNOTS+ on 5,000×4 at lag two versus the original uncached source.
- One GRACE basis-projection change: backward 2.1–2.5× faster, backward allocation volume 30–32% lower, complete discovery 2.01–2.07× faster. Adam is unchanged.
- 104 CPU tests and 91 statistical-only tests pass. Identical-weight/noise prediction, gradient and update comparisons pass. CUDA/Metal hardware and feature builds were not run in this CPU-only environment.

`causal-ts-rs/` contains updated source, tests, the original-model neural golden fixture and a rebuilt Linux x86-64 CPU executable. `iteration2/` contains the new report, six CSV tables, raw outputs, plots, test logs, source snapshots, measured binaries, provenance hashes and profiling/reproduction scripts. `iteration2/source-changes.patch` covers text source/documentation changes; the new large JSON fixture is included directly rather than in that patch. No code comments were added.

Root `REPORT.md`, `REPRODUCE.md`, `environment.json` and `optimization/` retain earlier benchmark history. Their old source/binary hashes and statements about unchanged GRACE apply to those earlier stages. Current hashes are in `iteration2/provenance.json`; bundle checksums are in `BUNDLE-SHA256.json`.

The starting archive was `causal-ts-optimized-2026-10-24.zip`, SHA-256 `6fd7fb63fe14972ddaa76777e2fa66b1f4623ef224f3272a0e812c8d2ecde766`. The pinned upstream reference is Bloomberg Causal-TS `0d1fae061b2445a51d0c8b75fc565d897dd54fb7`. Project licenses and upstream notices are retained.
""")
manifest = {path.relative_to(bundle).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(bundle.rglob("*")) if path.is_file() and path.name != "BUNDLE-SHA256.json"}
(bundle / "BUNDLE-SHA256.json").write_text(json.dumps(manifest, indent=2) + "\n")
subprocess.run(["python3", bundle / "iteration2/verify_delivery.py"], check=True, cwd=bundle)
for name in ("python_runner.py", "measure_process", "optimization/profile_grace_python.py", "optimization/grace-results/chain_1000x4_L2_grace_shared.json", "optimization/grace-results/chain_1000x8_L2_grace_shared.json"):
    assert (bundle / name).is_file(), name
for case in json.loads((bundle / "cases.json").read_text()):
    relative = Path(case["input"]).relative_to("/workspace/causal-benchmark")
    assert (bundle / relative).is_file(), relative
with zipfile.ZipFile(args.destination, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in sorted(bundle.rglob("*")):
        if path.is_file():
            archive.write(path, path.relative_to(staging))
with zipfile.ZipFile(args.destination) as archive:
    assert archive.testzip() is None
digest = hashlib.sha256(args.destination.read_bytes()).hexdigest()
args.destination.with_suffix(".zip.sha256").write_text(f"{digest}  {args.destination.name}\n")
print(json.dumps({"archive": str(args.destination), "bytes": args.destination.stat().st_size, "sha256": digest, "files": len(manifest) + 1}))
