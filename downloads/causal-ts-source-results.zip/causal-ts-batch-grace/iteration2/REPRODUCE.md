# Reproduce both tasks

Run from the extracted bundle root. Rust source is in `causal-ts-rs/`; this directory contains the follow-up evidence. `optimization/REPORT.md` and root `REPORT.md` describe earlier work and are historical. The current results are in `iteration2/REPORT.md`.

Recorded environment: Linux x86-64, Rust 1.99.1, Python 3.12.14, Candle 0.11.0, PyTorch 2.14.1+cpu, one thread pinned to CPU 0. See `iteration2/provenance.json`, `environment.json` and `requirements-lock.txt`. Change the CPU passed to `taskset` in the runners if CPU 0 is unavailable. Run timings sequentially without concurrent builds or other CPU-heavy work. The scripts overwrite their previous measurement output, so retain a copy of the delivered evidence before rerunning.

## Verify the source

```bash
cargo test --manifest-path causal-ts-rs/Cargo.toml --release --locked
cargo test --manifest-path causal-ts-rs/Cargo.toml --release --locked --no-default-features --lib --tests
cargo clippy --manifest-path causal-ts-rs/Cargo.toml --release --locked --all-targets -- -D warnings
cargo fmt --manifest-path causal-ts-rs/Cargo.toml --check
python3 optimization/generate_adam_profile.py --check
python3 iteration2/verify_delivery.py
```

The golden `grace_batch_reference.json` was generated before the production change. Do not regenerate it with the new model when testing equivalence. `grace_parity_fixture.rs` records how it was made. To check the original model again, copy `tests/grace_batch.rs` and `tests/fixtures/grace_batch_reference.json` into the same paths under `iteration2/baseline-source/`, then run its `--test grace_batch` in its own target directory. The delivered logs include this check for both contiguous and strided inputs.

## Rebuild the measured versions

```bash
python3 iteration2/build_benchmarks.py
cc -O2 -Wall -Wextra measure_process.c -o measure_process
```

Use `--offline` on the build script only when the locked dependencies are already cached. Each source snapshot has a separate Cargo target directory. Sharing a target directory between different paths with the same package name/version can reuse the wrong example artifact; the build script avoids this.

The snapshots are:

| Directory | Production source |
| --- | --- |
| `optimization/baseline-source/` | Original pre-covariance implementation, retained from the supplied bundle |
| `iteration2/baseline-source/` | Requested optimized archive; the new batch benchmark harness is added |
| `iteration2/task1-source/` | Requested archive plus the Task 1 CI change; original GRACE and original phase profiler |
| `causal-ts-rs/` | Both completed tasks |

The build script copies executables to the exact paths expected by the measurement runners. This compact download omits recorded benchmark binaries and retains their hashes under `omitted_rebuildable_binaries_sha256` in provenance.json. The build script recreates the binaries from the included source snapshots. The comparison example excludes CSV parsing and JSON serialization from its internal timer.

## Task 1

```bash
python3 iteration2/bench_task1.py
```

This measures the required two-query case, 128 repeated queries and 32 disjoint queries on 512×1,024 data, then all 14 CDNOTS/CDNOTS+ discovery cases. Use `--batch-only` for only the batch workloads. Batch calls get three warmups and 21 measurements; discovery gets two warmups and 11 measurements. Allocation counters are enabled for a separate batch call. Every full result is compared, with exact discrete fields and absolute floating-point tolerance `1e-9`.

## Task 2: operation and allocation profiles

```bash
python3 iteration2/build_benchmarks.py --profiles
python3 iteration2/run_kernel_profile.py before
python3 iteration2/run_kernel_profile.py candidate1
```

The first command generates a local copy of Candle 0.11.0 from Cargo's registry source and inserts per-node timing/allocation scopes in backward. It uses `CARGO_HOME`, or the normal `.cargo` directory in your home directory. Alternatively `prepare_profiler.py --candle-source /path/to/candle-core-0.11.0` accepts an explicit path. Production Cargo.toml and Cargo.lock are never patched.

`prepare_profiler.py --model-source ...` selects the old or new model and mechanically extracts the exact Adam update body with only `loss.backward()` separated. The standalone profiler includes the selected model snapshot. Each revision builds an unpatched allocator-only binary and an operation-instrumented binary in separate target directories. They use the same input, initial state and ChaCha8 gate noise, and the runner checks exact equality of the final parameter states after ten warmups and 20 measured steps. The source hashes are included in every profile.

The runner also repeats the supplied clean phase profiles for all three workloads, without the allocation or operation instrumentation. Those use seven reset blocks, ten warmups and 40 measured steps per block. Five instrumented updates are checked exactly against public Adam before timing. Headline phase values are medians of block means.

Allocation bytes are the sum of requested `alloc`, `alloc_zeroed` and `realloc` sizes during a phase. Realloc uses the new requested size; deallocations are not subtracted. They measure allocation traffic, not retained memory. No GPU allocation measurement is implied.

## Upstream Python and complete GRACE

Set up the pinned upstream checkout and Python environment:

```bash
git clone https://github.com/bloomberg/causal-ts.git upstream
git -C upstream checkout --detach 0d1fae061b2445a51d0c8b75fc565d897dd54fb7
uv venv --python python3.12 .venv
uv pip install --python .venv/bin/python --index-url https://download.pytorch.org/whl/cpu 'torch==2.14.1+cpu'
uv pip install --python .venv/bin/python -r requirements-lock.txt
uv pip install --python .venv/bin/python --no-deps -e upstream
.venv/bin/python iteration2/bench_grace_discovery.py
.venv/bin/python iteration2/analyze_results.py
```

Full discovery has two warmups and seven measured runs with 30 epochs, patience 31, batch 128, lag two and seed 42. The runner records every result and process peak RSS. It checks before/after/Python final graphs and native skeletons, lambda and epoch counts. It also repeats the Python phase profiles with the weights exported by the Rust before profile. Phase timings include gate sampling in forward, loss construction and scalar checks in loss, autodiff in backward, and moment/parameter updates in Adam; Python includes its normal RMSE calculation in loss and gradient reset in other time. Gate RNG streams differ during timed Rust/Python training. Identical-noise comparisons are covered separately by the neural fixtures.

## GPU checks

These commands were **not run** in the recorded CPU-only environment. They require the respective toolkit/SDK and hardware:

```bash
cargo test --manifest-path causal-ts-rs/Cargo.toml --release --locked --features cuda --test accelerator cuda_forward_backward_adam_and_ci -- --ignored
cargo test --manifest-path causal-ts-rs/Cargo.toml --release --locked --features metal --test accelerator metal_forward_backward_adam_and_ci -- --ignored
```

CPU unavailable-device validation did run. Backend features and standard Candle operations remain portable; no GPU compilation, runtime or speed result is claimed.
