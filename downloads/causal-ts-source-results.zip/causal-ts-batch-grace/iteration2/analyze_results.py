import csv
import json
import os
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent

def read(name):
    return json.loads((HERE / f"{name}.json").read_text())

def table(headers, rows):
    return "\n".join(["| " + " | ".join(headers) + " |", "| " + " | ".join(["---"] * len(headers)) + " |", *["| " + " | ".join(map(str, row)) + " |" for row in rows]])

def csv_file(name, rows):
    with (HERE / name).open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

batch = read("task1-batch-summary")
discovery = read("task1-discovery-summary")
grace = read("task2-discovery-summary")
phases = {r: read(f"task2-{r}-phase-summary") for r in ("before", "candidate1", "python")}
alloc = {r: read(f"task2-{r}-allocation-summary") for r in ("before", "candidate1")}
names = {"before": "Before", "candidate1": "After", "python": "PyTorch"}
batch_rows = []
batch_csv = []
for row in batch:
    a, b = [row["implementations"][k] for k in ("before_batch", "after_batch")]
    batch_rows.append([row["pattern"], a["query_count"], f"{a['median_ms']:.6f}", f"{b['median_ms']:.6f}", f"{a['median_ms']/b['median_ms']:.1f}×", f"{a['allocated_bytes']:,} → {b['allocated_bytes']:,}", f"{a['allocation_calls']} → {b['allocation_calls']}"])
    for implementation, values in row["implementations"].items():
        batch_csv.append(dict(pattern=row["pattern"], implementation=implementation, **{k: values[k] for k in ("query_count", "median_ms", "min_ms", "max_ms", "allocation_calls", "allocated_bytes", "peak_rss_kib")}))
csv_file("task1-batch.csv", batch_csv)
discovery_rows = []
discovery_csv = []
for row in discovery:
    discovery_rows.append([row["case"]["id"], *[f"{row['implementations'][k]['median_ms']:.4f}" for k in ("original", "supplied", "fixed")], f"{row['speedup_vs_original']:.2f}×"])
    for implementation, values in row["implementations"].items():
        discovery_csv.append(dict(case=row["case"]["id"], implementation=implementation, **{k: values[k] for k in ("median_ms", "min_ms", "max_ms", "peak_rss_kib")}, maximum_numeric_difference=row["maximum_numeric_difference"]))
csv_file("task1-discovery.csv", discovery_csv)
phase_rows = []
phase_csv = []
for index in range(3):
    for revision in phases:
        row = phases[revision][index]
        phase_rows.append([row["case"].removesuffix("_grace"), names[revision], *[f"{row['phases'][p]['median_ms']:.4f}" for p in ("forward_ms", "loss_ms", "backward_ms", "adam_ms", "other_ms", "total_ms")]])
        for phase, values in row["phases"].items():
            phase_csv.append(dict(case=row["case"], revision=revision, phase=phase, **{k: values[k] for k in ("median_ms", "min_ms", "max_ms")}))
csv_file("task2-phases.csv", phase_csv)
allocation_rows = []
allocation_csv = []
operation_csv = []
for index in range(2):
    before, after = [alloc[r][index] for r in ("before", "candidate1")]
    for phase in ("forward", "loss", "backward", "adam"):
        a, b = [x["phases"][phase] for x in (before, after)]
        allocation_rows.append([before["num_vars"], phase, f"{a['bytes']:,}", f"{b['bytes']:,}", f"{100*(1-b['bytes']/a['bytes']):.1f}%", f"{a['calls']} → {b['calls']}"])
    for row in (before, after):
        for phase, values in row["phases"].items():
            allocation_csv.append(dict(num_vars=row["num_vars"], revision=row["revision"], phase=phase, **values))
        for operation in row["operations"]:
            operation_csv.append(dict(num_vars=row["num_vars"], revision=row["revision"], **operation))
csv_file("task2-allocations.csv", allocation_csv)
csv_file("task2-operations.csv", operation_csv)
operation_rows = []
for row in alloc["before"]:
    d = row["num_vars"]
    selected = [x for x in row["operations"] if x["operation"] in (f"BinaryMul [128, {d}, 3, 3, 64]", f"Broadcast [1, {d}, 3, 3, 64] -> [128, {d}, 3, 3, 64]", f"ReduceSum [128, {d}, 3, 3, 64] -> [128, {d}, 3, 1, 64]")]
    assert len(selected) == 3
    for op in selected:
        operation_rows.append([d, op["operation"].split(" ")[0], f"{op['ms_per_step']:.4f}", f"{op['allocated_bytes_per_step']:,.0f}"])
    operation_rows.append([d, "Total for these three nodes", f"{sum(x['ms_per_step'] for x in selected):.4f}", f"{sum(x['allocated_bytes_per_step'] for x in selected):,.0f}"])
grace_rows = []
grace_csv = []
for row in grace:
    grace_rows.append([row["case"]["dataset"], *[f"{row['implementations'][k]['median_ms']:.3f}" for k in ("before", "after", "python")], f"{row['speedup']:.2f}×", f"{row['speedup_vs_python']:.2f}×"])
    for implementation, values in row["implementations"].items():
        grace_csv.append(dict(case=row["case"]["id"], implementation=implementation, **{k: values[k] for k in ("median_ms", "min_ms", "max_ms", "peak_rss_kib")}))
csv_file("task2-discovery.csv", grace_csv)
report = f"""# Batch CI and GRACE optimization — 2026-10-24

Both tasks passed. The required two-query batch falls from **23.980151 ms to 0.022637 ms**, with requested allocation volume falling from **19,008,616 to 70,664 bytes**. The discovery covariance cache retains its gains. One GRACE projection change cuts backward time by **2.1–2.5×**, backward allocation volume by **30–32%**, and complete discovery time by **2.01–2.07×** across the three measured workloads.

The starting point is `causal-ts-optimized-2026-10-24.zip`, SHA-256 `6fd7fb63fe14972ddaa76777e2fa66b1f4623ef224f3272a0e812c8d2ecde766`. Task 1 passed its CPU suite and result comparisons before Task 2 began; see [the completion record](task1-passed.json). Source changes are in [src/ci.rs](../causal-ts-rs/src/ci.rs) and [src/grace/model.rs](../causal-ts-rs/src/grace/model.rs). No code comments were added.

## Task 1: query-scoped covariance

`batch_test` validates and canonicalizes the queries, identifies their used columns, and prepares covariance only for the union of eligible complete queries. It borrows the selected data. Batches smaller than four, insufficient samples, GCMI, fewer than four reusable queries, or a poor estimated amortization use scalar testing. The estimate compares the sum of `width * (width + 8)` over eligible queries with twice that work for their union. This is a conservative planning heuristic, not a timing oracle.

Queries with missing values retain their own complete-row selection. The existing ill-conditioned/singular fallback, validation and result order are preserved. Discovery still prepares its immutable data-window cache. New regressions cover nonconsecutive indices, unused missing columns, repeated and disjoint queries, empty/small batches, mixed complete/missing columns, singular/constant inputs and invalid indices. The seven prepared-CI tests compare every result field against scalar testing.

### Required sparse-column benchmark

All cases use 512 rows and 1,024 input columns. `two` uses `(7, 511 | 1023)` and `(1023, 7)`; `repeated` repeats these queries 128 times; `disjoint` uses 32 different three-column subsets. Three warmups and 21 measured calls per configuration; allocation counts come from a separate call after timing. Input generation is excluded. Before is the supplied archive; after is the Task 1 implementation.

{table(['Pattern', 'Queries', 'Before ms', 'After ms', 'Speedup', 'Allocated bytes before → after', 'Allocation calls before → after'], batch_rows)}

For the required two queries, the new batch call uses scalar testing. Direct sequential scalar execution measured 0.018830 ms. An explicitly prepared three-column context measured 0.012571 ms, but that diagnostic excludes batch planning, index remapping and Rayon collection; it is not the public batch path. For 128 repeated queries, direct scalar execution was 1.186162 ms versus the new batch's 0.097472 ms. The disjoint case correctly avoids covariance preparation and measured 0.476512 ms versus 0.443544 ms for direct sequential scalar execution.

Maximum absolute cached/scalar difference across these benchmarks was `2.22e-16`; statuses, sample counts, conditioning sizes and result order agree. The required case's process peak RSS fell from 24,424 to 5,936 KiB. The number of allocation calls rises slightly while the allocated byte volume falls sharply. See [raw batch data](task1-batch-summary.json) and [CSV](task1-batch.csv).

### Discovery cache gains retained

Each version has two warmups and 11 measured calls. All 14 complete output objects retain exact discrete fields; maximum absolute floating-point difference is `{max(x['maximum_numeric_difference'] for x in discovery):.3g}`. `Original` is the implementation before covariance reuse, `Supplied` is the requested archive, and `Fixed` is Task 1. Cache construction is inside the timed discovery call.

{table(['Case', 'Original ms', 'Supplied ms', 'Fixed ms', 'Original / fixed'], discovery_rows)}

The nonstationary CDNOTS+ case did not benefit from the earlier covariance optimization and remains approximately unchanged. Timing ranges and RSS for every case are retained in [JSON](task1-discovery-summary.json) and [CSV](task1-discovery.csv).

## Task 2: one measured cause

An isolated Candle 0.11.0 profiler times graph sorting and individual backward nodes, recording the operation, tensor shapes and allocation deltas. The production dependency is unchanged; no Candle fork is used by the delivered library. A separate unpatched pass measures whole-phase allocations, and the existing clean phase profiler supplies the headline times. The operation and unpatched allocation runs finish with exactly identical parameter states for both four and eight variables, before and after.

The largest cost was the basis encoder's `[batch, variables, lags, 3, hidden]` broadcast product and its gradient reductions. The following are mean instrumented backward costs per step, batch 128, three lag slots, hidden width 64. The broadcast node's time is its backward reduction, not the cheap forward view.

{table(['Variables', 'Backward node', 'Instrumented ms', 'Requested allocation bytes'], operation_rows)}

On eight variables these three nodes account for 5.4833 ms of 9.5248 ms attributed to backward nodes (57.6%), including 18,934,216 requested bytes. The multiplication materializes large gradient tensors; the broadcast gradient reduces across the batch, and the sum gradient expands the basis dimension.

The only production GRACE change replaces `stack([x, x², abs(x)]) * W`, summed across the three basis terms, with a batched matrix multiplication. Inputs are arranged as `[variables * lags, batch, 3]`, weights as `[variables * lags, 3, hidden]`, and the output is restored to the existing layout before adding the same bias. This removes the expanded product while retaining the mathematical projection. Model dimensions, parameter names/layouts, loss, gate noise, gradients and Adam behavior remain covered by reference tests. Loss, gate and Adam source bodies are unchanged. Linear and nonlinear encoder paths are unchanged. No subsequent optimization was mixed into the measured candidate.

### Supplied phase profiles repeated

Times are milliseconds per training step, median of seven independently reset block means. Every block has ten warmup and 40 measured steps. Rust and PyTorch use the same exported initial weights, skeleton, model settings and first 128 normalized lag windows. Each uses its native random gate stream during timing; the numerical parity tests separately use identical explicit noise. Phase medians need not sum exactly to the independently calculated total median.

{table(['Case', 'Version', 'Forward', 'Loss', 'Backward', 'Adam', 'Other', 'Total'], phase_rows)}

Forward improves by about 2.7× and backward by 2.1–2.5×. Backward remains a large share because forward improved too. It is still about 1.55–1.85× slower than PyTorch's backward on these CPU workloads; this change does not eliminate every gap. Adam was not changed. See [phase CSV](task2-phases.csv) and the before/after/Python phase summary JSON files.

### Allocation measurements

These are mean requested CPU heap bytes per step, with ten warmups and 20 measured steps on the 1,000-row shared profile inputs. Counters wrap successful `alloc`, `alloc_zeroed` and `realloc` calls; realloc counts the requested new size. Freed bytes are not subtracted. These numbers measure allocation traffic, **not peak or live memory**. Atomics add overhead, so these runs are not used for headline timings. Per-operation records exclude their own label formatting; whole-phase totals come from the unpatched allocator-only pass.

{table(['Variables', 'Phase', 'Before bytes', 'After bytes', 'Byte reduction', 'Allocation calls before → after'], allocation_rows)}

Backward allocation counts rise slightly while byte volume falls. Adam bytes and allocation counts are exactly unchanged. The remaining eight-variable operation costs are spread among bias broadcast reductions (~0.72 ms), gate aggregation matmul (~0.56 ms), decoder slices (~0.52 ms), decoder matmuls (~0.51 ms) and decoder bias reductions (~0.49 ms), measured with operation instrumentation. All operations and shapes are retained in [CSV](task2-operations.csv); whole-phase values are in [allocation CSV](task2-allocations.csv).

### Complete GRACE discovery

Thirty epochs, patience 31, batch size 128, seed 42, maximum lag two, C included. Two warmups and seven measured discovery calls for each implementation, in seeded randomized order. Includes skeleton discovery, preprocessing, training and graph extraction. CSV parsing, process startup, imports and serialization are outside algorithm timing. Python is unmodified Bloomberg Causal-TS at `0d1fae061b2445a51d0c8b75fc565d897dd54fb7`. Before contains the passed Task 1 fix and the original GRACE model; after adds only the basis projection change.

{table(['Dataset', 'Rust before ms', 'Rust after ms', 'Python ms', 'Before / after', 'Python / after'], grace_rows)}

All final graphs match before/after and Python for these three cases. Native skeletons, selected lambda and epoch counts are exact. Maximum native gate difference is `5.96e-8`; maximum loss-history difference is `1.03e-7`. Equal final graphs on these cases do not establish equal training trajectories across unrelated Rust/Python RNG streams.

Process peak RSS drops from 17,728 to 10,956 KiB (300×4), 18,216 to 11,608 KiB (1,000×4), and 30,032 to 17,812 KiB (1,000×8). RSS includes the entire process, unlike allocation traffic. All samples, ranges, RSS and full results are in [discovery JSON](task2-discovery-summary.json), [CSV](task2-discovery.csv) and [raw results](task2-results/).

![GRACE discovery timing and backward allocation volume](grace-results.png)

## Correctness and backend checks

- **104 CPU tests passed**, including all ten existing neural/tensor reference tests, seven prepared-CI tests and two new GRACE batch tests. **91 statistical-only tests passed**. Strict Clippy and formatting passed.
- The new golden fixture was generated from the original supplied GRACE source before the change. Six cases cover four/eight variables, batches 1/13/128, contiguous and genuinely strided inputs, and two updates with identical transferred weights, skeletons and explicit gate noise. Both old and new models pass the fixture. Maximum errors: predictions `3.58e-7`, loss `2.39e-7`, all parameter/input gradients `3.34e-6`, updated parameters `1.87e-6`. Tests use absolute plus relative tolerances: `2e-5 + 2e-5*abs(reference)` for predictions/loss/updates; `5e-5 + 2e-5*abs(reference)` for gradients. Existing upstream fixture tolerances were not changed.
- Production CUDA/Metal feature flags and dependencies remain unchanged. The replacement uses standard portable Candle reshape/permute/contiguous/matmul/broadcast operations. **No CUDA or Metal hardware test or feature build ran**: this Linux environment has neither CUDA hardware/toolkit nor Apple hardware/SDK. Both opt-in GPU tests remain ignored. The CPU test for explicit unavailable-device errors passed.

Evidence: [CPU suite](task2-cpu-tests.log), [statistical suite](task2-core-tests.log), [original-model layout parity](task2-baseline-strided-parity.log), [optimized layout parity](task2-final-strided-parity.log), [Clippy](final-clippy.log), [formatting](final-fmt.log).

## Method and reproduction

Linux x86-64, Intel Xeon Platinum 8573C, Rust 1.99.1, Python 3.12.14, PyTorch 2.14.1+cpu, Candle 0.11.0. Release builds use thin LTO, one codegen unit and the default CPU target. Timing workers run sequentially, pinned to CPU 0 with one computation thread. No build was run concurrently with timing. Measurements are workload-specific; sample ranges are available rather than inferred confidence intervals.

Use [REPRODUCE.md](REPRODUCE.md). Separate Cargo target directories are required for separate source snapshots. An initial baseline batch build accidentally reused a current-source artifact; it was discarded, rebuilt in its own target directory and all batch measurements were repeated. Only the corrected batch measurements appear here and in `task1-results/`. The supplied source snapshot, Task 1 snapshot, original pre-covariance snapshot, model hashes and measured binary hashes are included. Allocation instrumentation is isolated from the production dependency graph.
"""
(HERE / "REPORT.md").write_text(report)
os.environ.setdefault("MPLCONFIGDIR", str(ROOT / ".mpl"))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
fig, axes = plt.subplots(1, 2, figsize=(12, 4.6), constrained_layout=True)
x = np.arange(3)
colors = {"before": "#8b919b", "after": "#126e82", "python": "#d29742"}
for offset, revision in zip((-0.26, 0, 0.26), ("before", "after", "python")):
    vals = [r["implementations"][revision]["median_ms"] / 1000 for r in grace]
    bars = axes[0].bar(x + offset, vals, width=0.25, color=colors[revision], label={"before": "Rust before", "after": "Rust after", "python": "Python"}[revision])
    axes[0].bar_label(bars, fmt="%.2f", fontsize=8)
axes[0].set_xticks(x, ["300 × 4", "1,000 × 4", "1,000 × 8"])
axes[0].set_ylabel("Discovery time (seconds)")
axes[0].set_title("Complete GRACE discovery")
axes[0].set_ylim(0, 4.2)
axes[0].legend(frameon=False)
x = np.arange(2)
for offset, revision, label in ((-0.17, "before", "Before"), (0.17, "candidate1", "After")):
    vals = [r["phases"]["backward"]["bytes"] / 1e6 for r in alloc[revision]]
    bars = axes[1].bar(x + offset, vals, width=0.32, color=colors["before" if revision == "before" else "after"], label=label)
    axes[1].bar_label(bars, fmt="%.1f MB")
axes[1].set_xticks(x, ["4 variables", "8 variables"])
axes[1].set_ylabel("Requested allocation bytes / step (MB)")
axes[1].set_title("Backward allocation traffic, batch 128")
axes[1].set_ylim(0, 68)
axes[1].legend(frameon=False)
fig.suptitle("One CPU thread · lag 2 · 30-epoch discovery · allocation traffic is not peak memory", fontsize=10)
fig.savefig(HERE / "grace-results.png", dpi=180)
fig.savefig(HERE / "grace-results.svg")
print("Generated report, six CSV tables, and PNG/SVG plots.")
