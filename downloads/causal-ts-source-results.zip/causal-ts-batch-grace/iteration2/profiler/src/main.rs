use candle_core::{Device, Tensor};
pub use causal_ts::{graph, Error, Result, TimeSeries};
use rand::SeedableRng;
use rand_chacha::ChaCha8Rng;
use serde_json::{json, Value};
use std::{fs::File, time::Instant};

mod allocator;
#[global_allocator]
static ALLOCATOR: allocator::CountingAllocator = allocator::CountingAllocator;

#[allow(dead_code)]
mod model {
    include!("model_source.rs");
    include!("adam_apply.rs");
}

fn tensor(v: &Value) -> Result<Tensor> {
    let values: Vec<f32> = serde_json::from_value(v["values"].clone())?;
    let shape: Vec<usize> = serde_json::from_value(v["shape"].clone())?;
    Ok(Tensor::from_vec(values, shape, &Device::Cpu)?)
}

fn main() -> std::result::Result<(), Box<dyn std::error::Error>> {
    rayon::ThreadPoolBuilder::new()
        .num_threads(1)
        .build_global()?;
    let args: Vec<_> = std::env::args().collect();
    let shared: Value = serde_json::from_reader(File::open(&args[1])?)?;
    let steps: usize = args.get(2).map(String::as_str).unwrap_or("20").parse()?;
    let d = shared["num_vars"].as_u64().unwrap() as usize;
    let lag = shared["max_lag"].as_u64().unwrap() as usize;
    let config = serde_json::from_value(shared["config"].clone())?;
    let skeleton = serde_json::from_value::<Vec<Vec<Vec<u8>>>>(shared["skeleton"].clone())?;
    let mut model = model::GatedModel::new(d, lag, &config, &Device::Cpu, 42)?;
    model.initialize_skeleton(&skeleton, true)?;
    model.load_state(&serde_json::from_value(shared["state"].clone())?)?;
    let x = tensor(&shared["input"])?;
    let lambda = shared["lambda"].as_f64().unwrap();
    let steps_per_epoch = shared["steps_per_epoch"].as_u64().unwrap() as usize;
    let mut rng = ChaCha8Rng::seed_from_u64(42);
    let mut optimizer = model::Adam::new();
    for _ in 0..10 {
        let u = model::uniform_noise(d, lag + 1, &mut rng, &Device::Cpu)?;
        let (mu, sigma) = model.forward(&x, Some(&u))?;
        let loss = model.loss(&x, &mu, &sigma, lambda, steps_per_epoch, true)?;
        optimizer.step(&model, &loss)?;
    }
    let mut samples = vec![];
    for _ in 0..steps {
        allocator::start();
        let start = Instant::now();
        let u = model::uniform_noise(d, lag + 1, &mut rng, &Device::Cpu)?;
        let (mu, sigma) = model.forward(&x, Some(&u))?;
        let forward_ms = start.elapsed().as_secs_f64() * 1000.0;
        let forward_alloc = allocator::stop();
        allocator::start();
        let start = Instant::now();
        let loss = model.loss(&x, &mu, &sigma, lambda, steps_per_epoch, true)?;
        assert!(loss.to_scalar::<f32>()?.is_finite());
        let loss_ms = start.elapsed().as_secs_f64() * 1000.0;
        let loss_alloc = allocator::stop();
        #[cfg(feature = "operations")]
        candle_core::profile::start();
        allocator::start();
        let start = Instant::now();
        let gradients = loss.backward()?;
        let backward_ms = start.elapsed().as_secs_f64() * 1000.0;
        let backward_alloc = allocator::stop();
        #[cfg(feature = "operations")]
        let operations: Vec<_> = candle_core::profile::finish().into_iter().map(|event| json!({
            "operation": event.operation, "nanoseconds": event.nanoseconds,
            "allocation_calls": event.allocation_calls, "allocated_bytes": event.allocated_bytes
        })).collect();
        #[cfg(not(feature = "operations"))]
        let operations: Vec<Value> = vec![];
        allocator::start();
        let start = Instant::now();
        optimizer.apply_gradients(&model, &gradients)?;
        let adam_ms = start.elapsed().as_secs_f64() * 1000.0;
        let adam_alloc = allocator::stop();
        samples.push(json!({"forward": {"ms": forward_ms, "calls": forward_alloc.0, "bytes": forward_alloc.1},
            "loss": {"ms": loss_ms, "calls": loss_alloc.0, "bytes": loss_alloc.1},
            "backward": {"ms": backward_ms, "calls": backward_alloc.0, "bytes": backward_alloc.1},
            "adam": {"ms": adam_ms, "calls": adam_alloc.0, "bytes": adam_alloc.1}, "operations": operations}));
    }
    println!(
        "{}",
        json!({"num_vars": d, "batch": x.dim(0)?, "max_lag": lag, "model_sha256": model::MODEL_SHA256,
        "operation_instrumentation": cfg!(feature = "operations"), "samples": samples, "final_state": model.state()?})
    );
    Ok(())
}
