pub const MODEL_SHA256: &str = "c0608e5ab53fa26714c8130be3fcf3962ed9eeb5176982b7d7deb5a7e56d52a8";
impl Adam {
    pub fn apply_gradients(&mut self, model: &GatedModel, gradients: &candle_core::backprop::GradStore) -> Result<()> {
        self.step += 1;
        let t = self.step as f64;
        for (name, p) in &model.parameters {
            let Some(gradient) = gradients.get(p) else {
                continue;
            };
            let gradient = (gradient + p.affine(model.config.weight_decay, 0.0)?)?.detach();
            let (m, v) = self
                .states
                .entry(name.clone())
                .or_insert((p.zeros_like()?, p.zeros_like()?));
            *m = (m.affine(0.9, 0.0)? + gradient.affine(0.1, 0.0)?)?.detach();
            *v = (v.affine(0.999, 0.0)? + gradient.sqr()?.affine(0.001, 0.0)?)?.detach();
            let denom = v
                .affine(1.0 / (1.0 - 0.999f64.powf(t)), 0.0)?
                .sqrt()?
                .affine(1.0, 1e-8)?;
            let delta = m
                .affine(model.config.lr / (1.0 - 0.9f64.powf(t)), 0.0)?
                .div(&denom)?;
            p.set(&(p.as_tensor() - delta)?.detach())?;
        }
        Ok(())
    }
}
