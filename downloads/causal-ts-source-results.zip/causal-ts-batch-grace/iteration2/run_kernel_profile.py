import collections
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUT = HERE / "task2-results"
OUT.mkdir(exist_ok=True)
revision = sys.argv[1]
env = os.environ.copy()
env.update({k: "1" for k in ("BENCH_THREADS", "RAYON_NUM_THREADS", "OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")})
records = []
for d in (4, 8):
    shared = ROOT / f"optimization/grace-results/chain_1000x{d}_L2_grace_shared.json"
    record = {"num_vars": d, "revision": revision}
    outputs = {}
    for mode in ("alloc", "ops"):
        path = OUT / f"{revision}_{d}vars_{mode}.json"
        with path.open("w") as stdout, path.with_suffix(".log").open("w") as stderr:
            subprocess.run(["taskset", "-c", "0", str(HERE / f"task2-{revision}-{mode}"), str(shared), "20"],
                           env=env, stdout=stdout, stderr=stderr, check=True, timeout=120)
        outputs[mode] = json.loads(path.read_text())
    assert outputs["alloc"]["final_state"] == outputs["ops"]["final_state"], "operation instrumentation changed model updates"
    record["instrumentation_parameter_parity"] = "exact"
    record["phases"] = {phase: {field: statistics.mean(s[phase][field] for s in outputs["alloc"]["samples"])
                               for field in ("ms", "calls", "bytes")} for phase in ("forward", "loss", "backward", "adam")}
    grouped = collections.defaultdict(lambda: collections.defaultdict(float))
    for sample in outputs["ops"]["samples"]:
        for event in sample["operations"]:
            group = grouped[event["operation"]]
            group["calls_per_step"] += 1/20
            group["ms_per_step"] += event["nanoseconds"] / 20e6
            group["allocation_calls_per_step"] += event["allocation_calls"] / 20
            group["allocated_bytes_per_step"] += event["allocated_bytes"] / 20
    record["operations"] = sorted([dict(operation=k, **v) for k, v in grouped.items()], key=lambda x: x["ms_per_step"], reverse=True)
    records.append(record)
    print(revision, d, record["phases"], flush=True)
    for op in record["operations"][:10]:
        print(op, flush=True)
(HERE / f"task2-{revision}-allocation-summary.json").write_text(json.dumps(records, indent=2)+"\n")

phase_records = []
for case in json.loads((ROOT / "cases.json").read_text()):
    if case["algorithm"] != "grace":
        continue
    request = dict(input=str(ROOT / Path(case["input"]).relative_to("/workspace/causal-benchmark")),
                   baseline_result=str(ROOT / "results" / (case["id"]+"_rust.json")),
                   shared_output=str(OUT / (revision+"_"+case["id"]+"_shared.json")), blocks=7, steps=40, warmups=10)
    request_path = OUT / (revision+"_"+case["id"]+"_request.json")
    request_path.write_text(json.dumps(request, indent=2)+"\n")
    path = OUT / (revision+"_"+case["id"]+"_phases.json")
    with path.open("w") as stdout, path.with_suffix(".log").open("w") as stderr:
        subprocess.run(["taskset", "-c", "0", str(HERE / f"task2-{revision}-profile"), str(request_path)],
                       stdout=stdout, stderr=stderr, env=env, check=True, timeout=120)
    data = json.loads(path.read_text())
    summary = {"case": case["id"], "revision": revision, "phases": {}}
    for phase in ("forward_ms", "loss_ms", "backward_ms", "adam_ms", "other_ms", "total_ms"):
        means = [statistics.mean(step[phase] for step in block) for block in data["blocks"]]
        summary["phases"][phase] = dict(median_ms=statistics.median(means), block_means_ms=means, min_ms=min(means), max_ms=max(means))
    phase_records.append(summary)
    print("PHASE", revision, case["id"], {p: round(v["median_ms"], 4) for p, v in summary["phases"].items()}, flush=True)
(HERE / f"task2-{revision}-phase-summary.json").write_text(json.dumps(phase_records, indent=2)+"\n")
