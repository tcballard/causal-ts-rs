import argparse
import hashlib
import os
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
parser = argparse.ArgumentParser()
parser.add_argument("--candle-source", type=Path)
parser.add_argument("--model-source", type=Path, default=ROOT / "causal-ts-rs/src/grace/model.rs")
args = parser.parse_args()
def write_if_changed(path, text):
    if not path.exists() or path.read_text() != text:
        path.write_text(text)

source = args.model_source.read_text()
write_if_changed(HERE / "profiler/src/model_source.rs", source)
start = source.index("    pub fn step(&mut self, model: &GatedModel, loss: &Tensor) -> Result<()> {")
end = source.index("\n    }\n}", start) + len("\n    }")
method = source[start:end]
method = method.replace("pub fn step(&mut self, model: &GatedModel, loss: &Tensor)",
                        "pub fn apply_gradients(&mut self, model: &GatedModel, gradients: &candle_core::backprop::GradStore)", 1)
method = method.replace("        let gradients = loss.backward()?;\n", "", 1)
generated = f'pub const MODEL_SHA256: &str = "{hashlib.sha256(source.encode()).hexdigest()}";\nimpl Adam {{\n{method}\n}}\n'
write_if_changed(HERE / "profiler/src/adam_apply.rs", generated)
if not (HERE / "profiler/Cargo.lock").exists():
    shutil.copy2(ROOT / "causal-ts-rs/Cargo.lock", HERE / "profiler/Cargo.lock")
if args.candle_source:
    candle = args.candle_source
else:
    cargo = Path(os.environ.get("CARGO_HOME", Path.home() / ".cargo"))
    candle = next((cargo / "registry/src").glob("*/candle-core-0.11.0"))
target = HERE / "candle-instrumented"
if not target.exists():
    shutil.copytree(candle, target)
backprop = (candle / "src/backprop.rs").read_text()
backprop = backprop.replace("        let sorted_nodes = self.sorted_nodes();", "        let sorted_nodes = {\n            let _profile = crate::profile::label(\"SortedNodes\".into());\n            self.sorted_nodes()\n        };", 1)
needle = "            if let Some(op) = node.op() {\n                match op {"
assert backprop.count(needle) == 1
backprop = backprop.replace(needle, "            if let Some(op) = node.op() {\n                let _profile = crate::profile::scope(op, node);\n                match op {", 1)
write_if_changed(target / "src/backprop.rs", backprop)
write_if_changed(target / "src/lib.rs", (candle / "src/lib.rs").read_text().replace("pub mod backprop;", "pub mod backprop;\npub mod profile;", 1))
shutil.copy2(HERE / "candle_profile.rs", target / "src/profile.rs")
print("Prepared timer-only Candle instrumentation and the unchanged Adam update body.")
