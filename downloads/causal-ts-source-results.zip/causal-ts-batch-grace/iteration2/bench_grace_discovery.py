import json
import os
from pathlib import Path
import random
import statistics
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUT = HERE / "task2-results"
OUT.mkdir(exist_ok=True)
env = os.environ.copy()
env.update({k: "1" for k in ("BENCH_THREADS", "RAYON_NUM_THREADS", "OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS")})
env.update(MPLCONFIGDIR=str(ROOT / ".mpl"), NUMBA_CACHE_DIR=str(ROOT / ".numba"), XDG_CACHE_HOME=str(ROOT / ".cache"))
commands = {"before": [str(HERE / "task2-before-compare")], "after": [str(HERE / "task2-candidate1-compare")],
            "python": [str(ROOT / ".venv/bin/python"), str(ROOT / "python_runner.py")]}

def maximum_difference(a, b):
    if isinstance(a, list):
        assert len(a) == len(b)
        return max((maximum_difference(x, y) for x, y in zip(a, b)), default=0.0)
    return abs(a-b)

rng = random.Random(42)
records = []
for case in json.loads((ROOT / "cases.json").read_text()):
    if case["algorithm"] != "grace":
        continue
    record = {"case": case, "implementations": {}}
    request = {k: case[k] for k in ("algorithm", "input", "config")}
    request["input"] = str(ROOT / Path(request["input"]).relative_to("/workspace/causal-benchmark"))
    request.update(runs=7, warmups=2)
    order = list(commands)
    rng.shuffle(order)
    results = {}
    for implementation in order:
        stem = OUT / f"discovery_{case['id']}_{implementation}"
        print("START", case["id"], implementation, flush=True)
        with stem.with_suffix(".json").open("w") as stdout, stem.with_suffix(".log").open("w") as stderr:
            subprocess.run([str(ROOT / "measure_process"), str(stem.with_suffix(".rss")), "taskset", "-c", "0", *commands[implementation]],
                           input=json.dumps(request)+"\n", text=True, env=env, stdout=stdout, stderr=stderr, check=True, timeout=180)
        output = json.loads(stem.with_suffix(".json").read_text())
        assert "error" not in output, output.get("error")
        results[implementation] = output["result"]
        values = output["times_ms"]
        record["implementations"][implementation] = dict(times_ms=values, median_ms=statistics.median(values),
            min_ms=min(values), max_ms=max(values), peak_rss_kib=int(stem.with_suffix(".rss").read_text()))
        print("DONE", case["id"], implementation, record["implementations"][implementation]["median_ms"], flush=True)
    a, b = results["before"], results["after"]
    assert a["graph"] == b["graph"] == results["python"]["graph"], case["id"]
    assert a["skeleton"] == b["skeleton"]
    assert a["lambda_l0"] == b["lambda_l0"]
    assert [r["epochs"] for r in a["training_runs"]] == [r["epochs"] for r in b["training_runs"]]
    record["parity"] = dict(graphs_exact=True, skeleton_exact=True, epochs_exact=True,
        max_gate_difference=maximum_difference(a["gate_values"], b["gate_values"]),
        max_loss_history_difference=maximum_difference([r["loss_history"] for r in a["training_runs"]], [r["loss_history"] for r in b["training_runs"]]))
    record["speedup"] = record["implementations"]["before"]["median_ms"] / record["implementations"]["after"]["median_ms"]
    record["speedup_vs_python"] = record["implementations"]["python"]["median_ms"] / record["implementations"]["after"]["median_ms"]
    records.append(record)
    (HERE / "task2-discovery-summary.json").write_text(json.dumps(records, indent=2)+"\n")
    print("COMPARE", case["id"], record["speedup"], record["speedup_vs_python"], record["parity"], flush=True)

phase_records = []
for case in json.loads((ROOT / "cases.json").read_text()):
    if case["algorithm"] != "grace":
        continue
    shared = OUT / ("before_"+case["id"]+"_shared.json")
    path = OUT / ("python_"+case["id"]+"_phases.json")
    with path.open("w") as stdout, path.with_suffix(".log").open("w") as stderr:
        subprocess.run(["taskset", "-c", "0", str(ROOT / ".venv/bin/python"), str(ROOT / "optimization/profile_grace_python.py"), str(shared)],
                       stdout=stdout, stderr=stderr, env=env, check=True, timeout=120)
    data = json.loads(path.read_text())
    phases = {}
    for phase in ("forward_ms", "loss_ms", "backward_ms", "adam_ms", "other_ms", "total_ms"):
        means = [statistics.mean(step[phase] for step in block) for block in data["blocks"]]
        phases[phase] = dict(median_ms=statistics.median(means), block_means_ms=means, min_ms=min(means), max_ms=max(means))
    phase_records.append(dict(case=case["id"], phases=phases))
    print("PYTHON PHASE", case["id"], {p: round(v["median_ms"], 4) for p, v in phases.items()}, flush=True)
(HERE / "task2-python-phase-summary.json").write_text(json.dumps(phase_records, indent=2)+"\n")
