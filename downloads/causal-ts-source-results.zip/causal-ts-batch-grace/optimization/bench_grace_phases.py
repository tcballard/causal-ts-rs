"""Run CPU GRACE phase profiles sequentially and summarize independent blocks."""
import csv
import json
import os
from pathlib import Path
import statistics
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUT = HERE / "grace-results"
OUT.mkdir(exist_ok=True)
env = os.environ.copy()
env.update({k: "1" for k in ("BENCH_THREADS", "RAYON_NUM_THREADS", "OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS")})
env.update(MPLCONFIGDIR=str(ROOT / ".mpl"), NUMBA_CACHE_DIR=str(ROOT / ".numba"), XDG_CACHE_HOME=str(ROOT / ".cache"))
cases = [c for c in json.loads((ROOT / "cases.json").read_text()) if c["algorithm"] == "grace"]
for case in cases:
    case["input"] = str(ROOT / Path(case["input"]).relative_to("/workspace/causal-benchmark"))
records = []
for case in cases:
    shared_path = OUT / (case["id"] + "_shared.json")
    request = dict(input=case["input"], baseline_result=str(ROOT / "results" / (case["id"]+"_rust.json")),
                   shared_output=str(shared_path), blocks=7, steps=40, warmups=10)
    request_path = OUT / (case["id"] + "_request.json")
    request_path.write_text(json.dumps(request, indent=2)+"\n")
    commands = {"rust": [str(ROOT / "causal-ts-rs/target/release/examples/profile_grace"), str(request_path)],
                "python": [str(ROOT / ".venv/bin/python"), str(HERE / "profile_grace_python.py"), str(shared_path)]}
    record = {"case": case, "blocks": 7, "steps_per_block": 40, "warmups_per_block": 10, "implementations": {}}
    for implementation, command in commands.items():
        stem = OUT / (case["id"] + "_" + implementation)
        with stem.with_suffix(".json").open("w") as stdout, stem.with_suffix(".log").open("w") as stderr:
            subprocess.run(["taskset", "-c", "0", *command], stdout=stdout, stderr=stderr, env=env, check=True, timeout=120)
        data = json.loads(stem.with_suffix(".json").read_text())
        phases = {}
        for phase in ("forward_ms", "loss_ms", "backward_ms", "adam_ms", "other_ms", "total_ms"):
            means = [statistics.mean(s[phase] for s in block) for block in data["blocks"]]
            phases[phase] = dict(median_ms=statistics.median(means), min_ms=min(means), max_ms=max(means), block_means_ms=means)
        record["implementations"][implementation] = phases
        print(case["id"], implementation, {p: round(v["median_ms"], 3) for p, v in phases.items()}, flush=True)
    records.append(record)
    (HERE / "grace-summary.json").write_text(json.dumps(records, indent=2)+"\n")
with (HERE / "grace-summary.csv").open("w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["case", "implementation", "phase", "median_block_mean_ms", "min_block_mean_ms", "max_block_mean_ms"])
    for record in records:
        for implementation, phases in record["implementations"].items():
            for phase, values in phases.items():
                writer.writerow([record["case"]["id"], implementation, phase, values["median_ms"], values["min_ms"], values["max_ms"]])
