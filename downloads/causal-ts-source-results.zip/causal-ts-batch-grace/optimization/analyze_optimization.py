"""Render the report and a standalone phase-timing figure from recorded results."""
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

HERE = Path(__file__).resolve().parent
parcorr = json.loads((HERE / "parcorr-summary.json").read_text())
grace = json.loads((HERE / "grace-summary.json").read_text())

def timing_table(records):
    lines = ["| Workload | Algorithm | Before (ms) | After (ms) | Speedup |",
             "| --- | --- | ---: | ---: | ---: |"]
    for r in records:
        a, b = (r["implementations"][x]["median_ms"] for x in ("before", "after"))
        lines.append(f'| {r["case"]["dataset"]} | {r["case"]["algorithm"]} | {a:.3f} | {b:.3f} | {a/b:.2f}× |')
    return "\n".join(lines)

phases = [("forward_ms", "Forward", "#31688e"), ("loss_ms", "Loss", "#c58a31"),
          ("backward_ms", "Backward", "#8a4b91"), ("adam_ms", "Adam", "#35a78b"),
          ("other_ms", "Other", "#b6bec7")]
fig, ax = plt.subplots(figsize=(10.5, 5.5))
ys = np.arange(6)
labels = []
phase_values = {p: [] for p, _, _ in phases}
for record in grace:
    label = record["case"]["dataset"].replace("_", " ")
    for implementation in ("rust", "python"):
        labels.append(label + "  /  " + ("Rust" if implementation == "rust" else "Python"))
        for phase, _, _ in phases:
            phase_values[phase].append(record["implementations"][implementation][phase]["median_ms"])
left = np.zeros(6)
for phase, name, color in phases:
    values = np.array(phase_values[phase])
    ax.barh(ys, values, left=left, height=0.66, label=name, color=color)
    if phase in ("forward_ms", "backward_ms", "adam_ms"):
        for y, start, value in zip(ys, left, values):
            if value >= 0.65:
                ax.text(start + value/2, y, f"{value:.2f}", ha="center", va="center", color="white", fontsize=9)
    left += values
for y, total in zip(ys, left):
    ax.text(total + .1, y, f"{total:.2f} ms", va="center", fontsize=9)
ax.set_yticks(ys, labels)
ax.invert_yaxis()
ax.set_xlim(0, max(left)*1.14)
ax.set_xlabel("Milliseconds per training step (sum of median block means)")
ax.set_title("GRACE: backward propagation dominates Rust step time", loc="left", pad=32, fontsize=14, fontweight="bold")
ax.text(0, 1.045, "CPU · one thread · batch 128 · lag 2 · default basis encoder / 64-wide decoders", transform=ax.transAxes, fontsize=10, color="#4a5560")
ax.xaxis.grid(True, alpha=.2)
ax.set_axisbelow(True)
for edge in ("top", "right", "left"):
    ax.spines[edge].set_visible(False)
ax.tick_params(axis="y", length=0)
ax.legend(ncol=5, loc="upper left", bbox_to_anchor=(0, -.15), frameon=False)
fig.tight_layout()
fig.savefig(HERE / "grace-phases.png", dpi=180, bbox_inches="tight")
fig.savefig(HERE / "grace-phases.svg", bbox_inches="tight")
plt.close(fig)

phase_table = ["| Workload | Implementation | Forward | Loss | Backward | Adam | Other | Total |",
               "| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |"]
for r in grace:
    for implementation in ("rust", "python"):
        vals = r["implementations"][implementation]
        numbers = " | ".join(f'{vals[p]["median_ms"]:.3f}' for p in [*[p for p, _, _ in phases], "total_ms"])
        phase_table.append(f'| {r["case"]["dataset"]} | {implementation} | {numbers} |')
phase_table = "\n".join(phase_table)
worst_error = max(r["parity"]["max_absolute_numeric_error"] for r in parcorr)
float_count = sum(r["parity"]["float_fields_checked"] for r in parcorr)
complete = [r for r in parcorr if r["case"]["algorithm"] != "cedar" and not r["case"]["id"].startswith("missing_")]
missing = [r for r in parcorr if r["case"]["id"].startswith("missing_")]
controls = [r for r in parcorr if r["case"]["algorithm"] == "cedar"]

report = f"""# ParCorr covariance reuse and GRACE phase profiling

Measured 2026-10-24 on an Intel Xeon Platinum 8573C, one CPU thread pinned to
CPU 0, Rust 1.99.1 release builds. The original uploaded implementation is the
before baseline. Upstream Python is Bloomberg commit
`0d1fae061b2445a51d0c8b75fc565d897dd54fb7`, with CPU PyTorch 2.14.1.

**The ParCorr optimization reduces CDNOTS on 5,000 rows × 4 variables, lag two,
from 69.306 ms to 1.423 ms: 48.71× faster.** Across the five synthetic complete-data
workloads, CDNOTS improves 12.26–48.71× and CDNOTS+ improves 6.20–11.74×.
All 24 before/after workloads retain every discrete result field. The largest
absolute floating-point difference across {float_count:,} compared values is
{worst_error:.3g}.

**GRACE profiling identifies backward propagation as the next target:** it takes
64–69% of native training-step time. Forward takes 27–32%; Adam takes about 3%.
The production GRACE model, training loop, and optimizer implementation have not
been changed. Its CI skeleton search benefits from the shared ParCorr change.

## Implemented change

Native ParCorr prepares one centered, normalized covariance matrix for an
immutable, aligned discovery window. CDNOTS and CDNOTS+ reuse small submatrices
for each well-conditioned test; repeated calls no longer rebuild and center all
observations. Conditioning algebra and p-value calculation remain per test.
The prepared object borrows its window, preventing reuse after mutation or with
a different dataset. CDNOTS+ constructs its extended lag columns before preparing
the context so every phase uses the same aligned rows.

Only tests whose selected columns are all complete use the cache. A selected
missing column takes the existing scalar path, selecting complete rows for that
particular test. An unrelated missing column does not remove rows from other
tests. Singular/ill-conditioned subsets retain the existing SVD fallback;
constant columns, insufficient samples, invalid indices and infinity rejection
retain their semantics.

`ConditionalIndependence::prepare` is an optional hook with a default scalar
fallback, preserving custom engines. The CLI forwards it. `CiEngine::batch_test`
also prepares covariance for multiple tests. CEDAR's varying sliced windows,
GCMI and tensor CI retain their existing paths.

The cache retains O(P²) covariance entries for P window columns; preparation uses
an O(TP) temporary normalized matrix. This trades some up-front work and memory
for avoiding repeated scans. For example, CDNOTS+ at 1,000 rows × 8 variables,
lag five, used 4.55 → 5.88 MiB peak process RSS. The 16-variable CDNOTS case was
about 49.1 MiB in both versions. Full raw RSS measurements are included.

## Discovery timings

Medians of 11 measured calls after two warmups per implementation. Each case uses
the same CSV and configuration; workers run sequentially in randomized order.
Cache construction is included in every discovery call. CSV parsing, process
startup and JSON serialization are excluded. Defaults are unchanged; complete
synthetic chains exclude C covariates, while fixture and nonstationarity cases
retain their recorded settings.

{timing_table(complete)}

The nonstationary CDNOTS+ case remains around 6.3 ms (1.4% slower in this run);
covariance reuse does not accelerate its kernel orientation stage. There is no
blanket speedup claim for every workload.

### Missing-data checks

Starting from the same 1,000-row/four-variable chain, every 19th observation is
missing in one column, or in every column with different offsets. Both algorithms
use lag two. Fully affected windows take the original scalar path and return
bit-for-bit identical numeric results. Small timing differences there should not
be attributed to covariance reuse.

{timing_table(missing)}

### CEDAR control workloads

CEDAR is unchanged and serves as a timing control.

{timing_table(controls)}

## Correctness and build checks

- 100 CPU tests passed; two hardware-specific tests remain ignored.
- 89 tests passed without default/neural features.
- Strict Clippy, formatting, and release builds passed.
- Five new tests cover 480 ordered complete-data CI queries, parallel batches,
  per-test missing-row counts, singular/near-singular/constant columns, invalid
  inputs and repeated discovery over different windows.
- Every discrete field in all 24 discovery outputs matches, including graphs,
  endpoint marks, CI test counts, conditioning sets and diagnostics. Numeric
  comparison threshold: absolute error ≤1e-9; observed maximum: {worst_error:.3g}.
- The existing batch/scalar test now allows tight floating-point tolerance
  because a cached matrix product and a scalar dot product round differently.
  Symmetry and conditioning-order equality remain exact.
- All three seeded GRACE discovery results match the original native snapshots
  exactly, including final gates and training histories. The optimized CLI's
  full CDNOTS result also matches the library result exactly.
- Each GRACE profile first verifies five instrumented Adam updates exactly
  against the public uninstrumented implementation, for every parameter.

## GRACE phase profile

Milliseconds per training step, batch 128, lag two, default basis encoder,
hidden/decoder width 64 and two hidden decoder layers. Each value is the median
of seven independent block means: reset model/optimizer state, ten warmup steps,
then 40 measured steps. Per-step timings and block ranges are in the raw files.

{phase_table}

The separately reported total is the median of whole-step block means; it need
not equal the sum of independently computed stage medians.

![GRACE forward, loss, backward, Adam and other time](grace-phases.png)

Rust backward is 3.3–3.8× slower than upstream PyTorch in these shapes; forward
is 2.1–2.5× slower. Rust Adam is already 3.1–3.7× faster. Prioritize operator and
allocation profiling within Candle backward, then forward. These timers locate
the expensive phase; they do not yet identify the specific tensor operator.
An Adam rewrite is not supported as the next optimization by these results.

The profiling example includes the unchanged production model source. Its
timer-only Adam method is generated directly from the production body, separating
`loss.backward()` from moment and parameter updates. Source hashes and the
generation check are retained. There is no alternate optimized GRACE algorithm
hidden in the profiler.

Python receives the exact initial Rust weights, batch tensor, skeleton and
regularization settings. Native RNG streams differ, so later training states
can diverge. Forward includes normal random gate sampling; loss includes scalar
checks and Python's normal RMSE calculation. Other time includes cleanup and
Python gradient reset. The profile excludes CI discovery, input preparation,
batch selection, Lightning orchestration, validation and output. It is a model
training profile, not an end-to-end discovery speedup measurement.

## Artifacts

- [Reproduction instructions](REPRODUCE.md)
- [ParCorr summary CSV](parcorr-summary.csv) and [JSON with raw timing samples](parcorr-summary.json)
- [GRACE phase summary CSV](grace-summary.csv) and [JSON with block means](grace-summary.json)
- [GRACE figure SVG](grace-phases.svg)
- [Delivery verification](delivery-verification.json)
- [Source changes](source-changes.json) and [reviewable patch](changes.patch)
- Raw discovery outputs: `parcorr-results/`; raw phase profiles and shared inputs: `grace-results/`.

Measurements cover this CPU and these data/configurations. They do not establish
GPU performance or universal numerical equivalence at decision thresholds.
"""
(HERE / "REPORT.md").write_text(report)
print("Wrote REPORT.md and grace-phases.png/svg")
