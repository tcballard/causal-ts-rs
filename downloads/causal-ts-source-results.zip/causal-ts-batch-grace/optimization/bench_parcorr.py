"""Compare original and prepared-ParCorr binaries, including all result fields."""
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import random
import statistics
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUT = HERE / "parcorr-results"
OUT.mkdir(exist_ok=True)
env = os.environ.copy()
env.update({k: "1" for k in ("BENCH_THREADS", "RAYON_NUM_THREADS", "OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")})
binaries = {"before": HERE / "baseline-compare", "after": ROOT / "causal-ts-rs/target/release/examples/compare"}
cases = [c for c in json.loads((ROOT / "cases.json").read_text()) if c["algorithm"] != "grace"]
for case in cases:
    case["input"] = str(ROOT / Path(case["input"]).relative_to("/workspace/causal-benchmark"))
# Include partially missing and wholly affected windows to exercise both paths.
for pattern in ("one_column", "all_columns"):
    source = ROOT / "datasets/chain_1000x4.csv"
    rows = list(csv.reader(source.open()))
    for i, row in enumerate(rows[1:]):
        for j in range(4) if pattern == "all_columns" else [1]:
            if (i + 3*j) % 19 == 0:
                row[j] = "NaN"
    path = OUT / f"missing_{pattern}.csv"
    with path.open("w", newline="") as f:
        csv.writer(f).writerows(rows)
    for algorithm in ("cdnots", "cdnots+"):
        cfg = {"max_lag": 2, "include_c": False}
        cases.append(dict(id=f"missing_{pattern}_{algorithm.replace('+', 'plus')}",
                          dataset=f"missing_{pattern}", input=str(path), rows=1000, columns=4,
                          algorithm=algorithm, config={"discovery": cfg} if algorithm.endswith("+") else cfg,
                          sha256=hashlib.sha256(path.read_bytes()).hexdigest()))

def compare(a, b):
    """Require exact discrete structure and absolute error <=1e-9 for floats."""
    maximum = 0.0
    count = 0
    def walk(x, y, path="result"):
        nonlocal maximum, count
        if isinstance(x, float) or isinstance(y, float):
            assert isinstance(x, (int, float)) and isinstance(y, (int, float)), path
            error = abs(x-y)
            maximum = max(maximum, error)
            count += 1
            assert math.isfinite(error) and error <= 1e-9, (path, x, y)
        elif isinstance(x, dict):
            assert x.keys() == y.keys(), path
            for k in x:
                walk(x[k], y[k], path + "." + k)
        elif isinstance(x, list):
            assert len(x) == len(y), path
            for i, (left, right) in enumerate(zip(x, y)):
                walk(left, right, f"{path}[{i}]")
        else:
            assert x == y, (path, x, y)
    walk(a, b)
    return {"all_fields_match": True, "max_absolute_numeric_error": maximum, "float_fields_checked": count}

rng = random.Random(42)
records = []
for case in cases:
    responses = {}
    record = {"case": case, "implementations": {}}
    order = list(binaries)
    rng.shuffle(order)
    for implementation in order:
        stem = OUT / (case["id"] + "_" + implementation)
        request = {k: case[k] for k in ("algorithm", "input", "config")}
        request.update(runs=11, warmups=2)
        command = [str(ROOT / "measure_process"), str(stem.with_suffix(".rss")), "taskset", "-c", "0", str(binaries[implementation])]
        with stem.with_suffix(".json").open("w") as stdout, stem.with_suffix(".log").open("w") as stderr:
            subprocess.run(command, input=json.dumps(request)+"\n", text=True, env=env,
                           stdout=stdout, stderr=stderr, check=True, timeout=180)
        response = json.loads(stem.with_suffix(".json").read_text())
        assert "error" not in response, response.get("error")
        responses[implementation] = response["result"]
        times = response["times_ms"]
        record["implementations"][implementation] = dict(times_ms=times, median_ms=statistics.median(times),
            min_ms=min(times), max_ms=max(times), peak_rss_kib=int(stem.with_suffix(".rss").read_text()))
    record["parity"] = compare(responses["before"], responses["after"])
    record["speedup"] = record["implementations"]["before"]["median_ms"] / record["implementations"]["after"]["median_ms"]
    print(case["id"], f'{record["implementations"]["before"]["median_ms"]:.3f} -> {record["implementations"]["after"]["median_ms"]:.3f} ms ({record["speedup"]:.2f}x)', record["parity"], flush=True)
    records.append(record)
    (HERE / "parcorr-summary.json").write_text(json.dumps(records, indent=2)+"\n")
with (HERE / "parcorr-summary.csv").open("w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["case", "before_median_ms", "after_median_ms", "speedup", "max_absolute_numeric_error"])
    for r in records:
        writer.writerow([r["case"]["id"], r["implementations"]["before"]["median_ms"], r["implementations"]["after"]["median_ms"], r["speedup"], r["parity"]["max_absolute_numeric_error"]])
(HERE / "binary-hashes.json").write_text(json.dumps({k: hashlib.sha256(v.read_bytes()).hexdigest() for k, v in binaries.items()}, indent=2)+"\n")
