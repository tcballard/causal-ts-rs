"""Package source, binaries and reproducible measurement evidence."""
import datetime
import difflib
import hashlib
import json
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SOURCE = ROOT / "causal-ts-rs"
BASELINE = HERE / "baseline-source"

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

source_files = sorted(p for p in SOURCE.rglob("*") if p.is_file() and not any(part in {"target", ".git", "out", "__pycache__"} for part in p.relative_to(SOURCE).parts))
(SOURCE / "SHA256SUMS").write_text("".join(f"{digest(p)}  {p.relative_to(SOURCE)}\n" for p in source_files if p.name != "SHA256SUMS"))
changes = []
patch = []
for path in source_files:
    relative = path.relative_to(SOURCE)
    if path.suffix not in {".rs", ".toml", ".md"} and path.name != "Cargo.lock":
        continue
    baseline = BASELINE / relative
    # The saved baseline contains all Rust/build files and the edited documentation.
    # Omit unchanged original docs that were not copied into the minimal baseline.
    if not baseline.exists() and path.suffix == ".md":
        continue
    before = baseline.read_bytes() if baseline.exists() else b""
    after = path.read_bytes()
    if before == after:
        continue
    changes.append({"path": str(relative), "before_sha256": hashlib.sha256(before).hexdigest() if baseline.exists() else None,
                    "after_sha256": digest(path), "status": "modified" if baseline.exists() else "added"})
    patch.extend(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True),
                 fromfile="a/"+str(relative) if baseline.exists() else "/dev/null", tofile="b/"+str(relative)))
(HERE / "changes.patch").write_text("".join(patch))
unchanged = {}
for relative in ("src/grace/model.rs", "src/grace/mod.rs", "Cargo.lock"):
    assert (SOURCE / relative).read_bytes() == (BASELINE / relative).read_bytes(), relative
    unchanged[relative] = digest(SOURCE / relative)
(HERE / "source-changes.json").write_text(json.dumps({"changes": changes, "verified_unchanged": unchanged}, indent=2)+"\n")

environment = json.loads((ROOT / "environment.json").read_text())
environment.update(date_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    native_binary_sha256=digest(SOURCE / "target/release/causal-ts"),
    prebuilt_sha256=digest(SOURCE / "prebuilt/linux-x86_64/causal-ts"),
    benchmark_binary_sha256=digest(SOURCE / "target/release/examples/compare"),
    baseline_benchmark_sha256=digest(HERE / "baseline-compare"),
    profiling_binary_sha256=digest(SOURCE / "target/release/examples/profile_grace"),
    unchanged_grace_source=unchanged, measurement="ParCorr before/after and GRACE CPU phase profile")
(HERE / "environment.json").write_text(json.dumps(environment, indent=2)+"\n")

archive = ROOT.parent / "causal-ts-optimized-2026-10-24.zip"
prefix = "causal-ts-optimized/"
obsolete_logs = {"full-tests.log", "clippy.log", "fmt.log", "build.log", "baseline-causal-ts"}
readme = """# Causal-TS Rust: covariance reuse and GRACE profile

Start with [the optimization report](optimization/REPORT.md).
CDNOTS on the 5,000-row/four-variable workload improved from 69.306 ms to
1.423 ms (48.71×). All 24 before/after workloads preserve discrete outputs;
100 CPU tests pass. Missing-data handling remains per test.

GRACE backward propagation takes 64–69% of the measured native training step;
its model and optimizer implementation remain unchanged.

- Updated Rust source and Linux CPU executable: `causal-ts-rs/`.
- Reviewable source patch: `optimization/changes.patch`.
- [Build and measurement instructions](optimization/REPRODUCE.md).
- Raw measurements, profile inputs, provenance and test logs: `optimization/`.
- The original native baseline source and benchmark executable are included.

This is an optimization of package version 0.2.0, not a newly published release.
The Python source is pinned to Bloomberg commit
`0d1fae061b2445a51d0c8b75fc565d897dd54fb7`; clone instructions are included.
"""
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    z.writestr(prefix + "README.md", readme)
    for p in source_files:
        z.write(p, prefix+str(p.relative_to(ROOT)))
    for p in sorted(HERE.rglob("*")):
        if not p.is_file() or p.name in obsolete_logs or any(part in {"target", "__pycache__"} for part in p.relative_to(HERE).parts):
            continue
        z.write(p, prefix+str(p.relative_to(ROOT)))
    for directory in ["datasets"]:
        for p in sorted((ROOT / directory).rglob("*")):
            if p.is_file():
                z.write(p, prefix+str(p.relative_to(ROOT)))
    for name in ["cases.json", "environment.json", "requirements-lock.txt", "measure_process.c"]:
        z.write(ROOT/name, prefix+name)
    for p in sorted((ROOT / "results").glob("*_grace_rust.json")):
        z.write(p, prefix+str(p.relative_to(ROOT)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    names = set(z.namelist())
    for required in ["optimization/REPORT.md", "optimization/changes.patch", "causal-ts-rs/LICENSE",
                     "causal-ts-rs/tests/prepared_ci.rs", "causal-ts-rs/examples/profile_grace/adam_profile.rs",
                     "results/chain_1000x8_L2_grace_rust.json"]:
        assert prefix + required in names, required
    for line in (SOURCE / "SHA256SUMS").read_text().splitlines():
        expected, relative = line.split("  ", 1)
        assert hashlib.sha256(z.read(prefix+"causal-ts-rs/"+relative)).hexdigest() == expected, relative
checksum = digest(archive)
archive.with_suffix(".zip.sha256").write_text(checksum+"  "+archive.name+"\n")
print(json.dumps({"archive": str(archive), "bytes": archive.stat().st_size, "sha256": checksum,
                  "source_files_changed": len(changes), "archive_integrity": "verified"}, indent=2))
