"""Time the unmodified upstream model on the Rust profiler's initial state/input."""
import json
import math
from pathlib import Path
import sys
import time

import numpy as np
import torch
from causalts.grace.gated_discovery import GatedCausalDiscovery

torch.set_num_threads(1)
torch.set_num_interop_threads(1)
shared = json.loads(Path(sys.argv[1]).read_text())
config = shared["config"].copy()
config["wd"] = config.pop("weight_decay")
budget = config.pop("per_pair_lag_budget")
if budget is not None:
    config["max_lags_per_pair"] = np.asarray(budget)
x = torch.tensor(shared["input"]["values"], dtype=torch.float32).reshape(shared["input"]["shape"])
initial_state = {k: torch.tensor(v["values"], dtype=torch.float32).reshape(v["shape"]) for k, v in shared["state"].items()}
blocks = []
for _ in range(shared["blocks"]):
    torch.manual_seed(42)
    model = GatedCausalDiscovery(num_vars=shared["num_vars"], max_lag=shared["max_lag"],
        lambda_l0=shared["lambda"], steps_per_epoch=shared["steps_per_epoch"], **config)
    model.set_skeleton_mask(np.asarray(shared["skeleton"]))
    mismatch = model.load_state_dict(initial_state, strict=False)
    assert not mismatch.unexpected_keys, mismatch
    assert set(mismatch.missing_keys) == {"gate_mask"}, mismatch
    model.train()
    optimizer = model.configure_optimizers()
    times = []
    for step in range(shared["warmups"] + shared["steps"]):
        total_start = time.perf_counter_ns()
        optimizer.zero_grad(set_to_none=True)
        start = time.perf_counter_ns()
        mu, sigma = model.forward(x)
        forward_ms = (time.perf_counter_ns() - start) / 1e6
        start = time.perf_counter_ns()
        loss, rmse = model.get_loss(mu, sigma, x)
        assert math.isfinite(loss.item())
        loss_ms = (time.perf_counter_ns() - start) / 1e6
        start = time.perf_counter_ns()
        loss.backward()
        backward_ms = (time.perf_counter_ns() - start) / 1e6
        start = time.perf_counter_ns()
        optimizer.step()
        adam_ms = (time.perf_counter_ns() - start) / 1e6
        del mu, sigma, loss
        total_ms = (time.perf_counter_ns() - total_start) / 1e6
        if step >= shared["warmups"]:
            times.append(dict(forward_ms=forward_ms, loss_ms=loss_ms, backward_ms=backward_ms,
                adam_ms=adam_ms, total_ms=total_ms, other_ms=total_ms-forward_ms-loss_ms-backward_ms-adam_ms))
    blocks.append(times)
print(json.dumps(dict(implementation="python", batch=x.shape[0], num_vars=shared["num_vars"],
    max_lag=shared["max_lag"], torch_version=torch.__version__, blocks=blocks)))
