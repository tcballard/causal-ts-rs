"""Verify unchanged seeded GRACE results and the optimized CLI wrapper."""
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
env = os.environ.copy()
env.update({k: "1" for k in ("BENCH_THREADS", "RAYON_NUM_THREADS", "OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")})
cases = json.loads((ROOT / "cases.json").read_text())
verified = {}
for case in cases:
    if case["algorithm"] != "grace":
        continue
    request = {k: case[k] for k in ("algorithm", "input", "config")}
    request["input"] = str(ROOT / Path(request["input"]).relative_to("/workspace/causal-benchmark"))
    request.update(runs=1, warmups=0)
    result = subprocess.run(["taskset", "-c", "0", str(ROOT / "causal-ts-rs/target/release/examples/compare")],
                            input=json.dumps(request)+"\n", capture_output=True, text=True, check=True, env=env, timeout=90)
    after = json.loads(result.stdout)
    before = json.loads((ROOT / "results" / (case["id"] + "_rust.json")).read_text())
    assert after["result"] == before["result"], case["id"]
    (HERE / "grace-results" / (case["id"] + "_discovery_check.json")).write_text(result.stdout)
    verified[case["id"]] = "entire result exactly matches original Rust snapshot"

output = HERE / "cli-check.json"
subprocess.run([str(ROOT / "causal-ts-rs/target/release/causal-ts"), "discover", "--algorithm", "cdnots",
                "--input", str(ROOT / "datasets/chain_5000x4.csv"), "--no-c", "--max-lag", "2", "--output", str(output)],
               check=True, env=env, timeout=30)
expected = json.loads((HERE / "parcorr-results/chain_5000x4_L2_cdnots_after.json").read_text())["result"]
assert json.loads(output.read_text()) == expected, "CLI differs from native API"
verified["cli_cdnots_5000x4"] = "entire result exactly matches optimized native API"
(HERE / "delivery-verification.json").write_text(json.dumps(verified, indent=2)+"\n")
print(json.dumps(verified, indent=2))
