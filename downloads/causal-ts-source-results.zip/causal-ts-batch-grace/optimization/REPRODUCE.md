# Reproduce the ParCorr optimization and GRACE profile

Run from the extracted bundle root. The layout contains `causal-ts-rs/`,
`optimization/`, `datasets/`, and the original `cases.json`. The scripts rebase
the manifest's recorded paths to the extracted directory.

The recorded environment is Linux x86-64, Rust 1.99.1, Python 3.12.14, one CPU
thread pinned to CPU 0, and release builds with thin LTO and one codegen unit.
`environment.json` and `requirements-lock.txt` record the original toolchain
and Python dependencies. Change the `taskset` CPU in the scripts if CPU 0 is
not available on your machine.

## Build and verify Rust

```bash
cargo test --manifest-path causal-ts-rs/Cargo.toml --release --locked
cargo test --manifest-path causal-ts-rs/Cargo.toml --release --locked --no-default-features --lib --tests
cargo clippy --manifest-path causal-ts-rs/Cargo.toml --release --locked --all-targets -- -D warnings
cargo fmt --manifest-path causal-ts-rs/Cargo.toml --check
python3 optimization/generate_adam_profile.py --check

cargo build --manifest-path causal-ts-rs/Cargo.toml --release --locked --bin causal-ts --example compare --example profile_grace
cargo build --manifest-path optimization/baseline-source/Cargo.toml --release --locked --example compare
cp optimization/baseline-source/target/release/examples/compare optimization/baseline-compare
cc -O2 -Wall -Wextra measure_process.c -o measure_process
```

The baseline source is the original Rust implementation plus the original
benchmark harness. The recorded baseline executable is also included, but
rebuilding both versions on the same machine is preferable for new measurements.

## ParCorr benchmark

```bash
python3 optimization/bench_parcorr.py
```

This runs 20 original statistical workloads plus four missing-data workloads.
Each implementation gets two warmups and 11 measured algorithm calls. CSV input,
imports, process startup and JSON output are excluded. Cache construction within
each discovery call is included. Workers run sequentially in a seeded randomized
order, pinned to CPU 0 with one computational thread. Do not build or run other
CPU-heavy work concurrently. The C launcher measures process peak RSS, including
CSV input and JSON serialization, separately from algorithm timing.

Results are in `optimization/parcorr-summary.{json,csv}`. Raw timings, full result
objects, datasets with missing values, and RSS measurements are under
`optimization/parcorr-results/`. Every discrete result field must agree exactly;
all floating-point fields must have absolute error at most `1e-9`.

## GRACE phase profile

Set up the pinned upstream Python implementation using Python 3.12 and `uv`:

```bash
git clone https://github.com/bloomberg/causal-ts.git upstream
git -C upstream checkout --detach 0d1fae061b2445a51d0c8b75fc565d897dd54fb7
uv venv --python python3.12 .venv
uv pip install --python .venv/bin/python --index-url https://download.pytorch.org/whl/cpu 'torch==2.14.1+cpu'
uv pip install --python .venv/bin/python -r requirements-lock.txt
uv pip install --python .venv/bin/python --no-deps -e upstream
.venv/bin/python optimization/bench_grace_phases.py
.venv/bin/python optimization/verify_delivery.py
```

The Rust profiling example includes the unchanged production `model.rs` and a
timer-only version of `Adam::step`, generated mechanically by
`generate_adam_profile.py`. It times `loss.backward()` separately from the
remaining optimizer body. Before profiling, five updates must match the public,
uninstrumented implementation exactly for every parameter.

Each workload has seven independent model/optimizer initializations. Each block
runs ten warmup steps followed by 40 measured steps on the first 128 normalized
lag windows. Blocks reset weights and optimizer state. Reported stage times are
the medians of the seven block means; individual steps and block means are saved.

Rust exports the initial weights, input tensor, skeleton, model configuration,
and regularization settings to Python. Both run the same shapes and starting
state, with each implementation's native gate RNG; training trajectories need
not match. Both include gate sampling in forward, loss construction/scalar checks
in loss, backpropagation in backward, and only parameter/moment updates in Adam.
Other time includes cleanup and Python's gradient reset. Python's loss routine
also computes its normal RMSE metric. CPU execution is synchronous.

The profile excludes skeleton discovery, CSV preparation, batch sampling,
initialization, Lightning orchestration, validation, graph extraction and output.
It measures model training kernels, not complete GRACE discovery. Production
GRACE model and optimizer source remain unchanged.

Summaries are `optimization/grace-summary.{json,csv}`; raw per-step timings and
shared model inputs are in `optimization/grace-results/`. The original native
GRACE result snapshots in `results/` supply skeletons and regularization values.
