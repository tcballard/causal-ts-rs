# ParCorr covariance reuse and GRACE phase profiling

Measured 2026-10-24 on an Intel Xeon Platinum 8573C, one CPU thread pinned to
CPU 0, Rust 1.99.1 release builds. The original uploaded implementation is the
before baseline. Upstream Python is Bloomberg commit
`0d1fae061b2445a51d0c8b75fc565d897dd54fb7`, with CPU PyTorch 2.14.1.

**The ParCorr optimization reduces CDNOTS on 5,000 rows × 4 variables, lag two,
from 69.306 ms to 1.423 ms: 48.71× faster.** Across the five synthetic complete-data
workloads, CDNOTS improves 12.26–48.71× and CDNOTS+ improves 6.20–11.74×.
All 24 before/after workloads retain every discrete result field. The largest
absolute floating-point difference across 110,141 compared values is
2.41e-12.

**GRACE profiling identifies backward propagation as the next target:** it takes
64–69% of native training-step time. Forward takes 27–32%; Adam takes about 3%.
The production GRACE model, training loop, and optimizer implementation have not
been changed. Its CI skeleton search benefits from the shared ParCorr change.

## Implemented change

Native ParCorr prepares one centered, normalized covariance matrix for an
immutable, aligned discovery window. CDNOTS and CDNOTS+ reuse small submatrices
for each well-conditioned test; repeated calls no longer rebuild and center all
observations. Conditioning algebra and p-value calculation remain per test.
The prepared object borrows its window, preventing reuse after mutation or with
a different dataset. CDNOTS+ constructs its extended lag columns before preparing
the context so every phase uses the same aligned rows.

Only tests whose selected columns are all complete use the cache. A selected
missing column takes the existing scalar path, selecting complete rows for that
particular test. An unrelated missing column does not remove rows from other
tests. Singular/ill-conditioned subsets retain the existing SVD fallback;
constant columns, insufficient samples, invalid indices and infinity rejection
retain their semantics.

`ConditionalIndependence::prepare` is an optional hook with a default scalar
fallback, preserving custom engines. The CLI forwards it. `CiEngine::batch_test`
also prepares covariance for multiple tests. CEDAR's varying sliced windows,
GCMI and tensor CI retain their existing paths.

The cache retains O(P²) covariance entries for P window columns; preparation uses
an O(TP) temporary normalized matrix. This trades some up-front work and memory
for avoiding repeated scans. For example, CDNOTS+ at 1,000 rows × 8 variables,
lag five, used 4.55 → 5.88 MiB peak process RSS. The 16-variable CDNOTS case was
about 49.1 MiB in both versions. Full raw RSS measurements are included.

## Discovery timings

Medians of 11 measured calls after two warmups per implementation. Each case uses
the same CSV and configuration; workers run sequentially in randomized order.
Cache construction is included in every discovery call. CSV parsing, process
startup and JSON serialization are excluded. Defaults are unchanged; complete
synthetic chains exclude C covariates, while fixture and nonstationarity cases
retain their recorded settings.

| Workload | Algorithm | Before (ms) | After (ms) | Speedup |
| --- | --- | ---: | ---: | ---: |
| fixture_300x4_L2 | cdnots | 1.688 | 0.370 | 4.57× |
| fixture_300x4_L2 | cdnots+ | 0.720 | 0.194 | 3.70× |
| chain_1000x4_L2 | cdnots | 12.397 | 0.850 | 14.59× |
| chain_1000x4_L2 | cdnots+ | 2.222 | 0.331 | 6.72× |
| chain_5000x4_L2 | cdnots | 69.306 | 1.423 | 48.71× |
| chain_5000x4_L2 | cdnots+ | 12.472 | 1.062 | 11.74× |
| chain_1000x8_L2 | cdnots | 61.269 | 4.140 | 14.80× |
| chain_1000x8_L2 | cdnots+ | 8.267 | 0.994 | 8.32× |
| chain_1000x8_L5 | cdnots | 235.224 | 16.936 | 13.89× |
| chain_1000x8_L5 | cdnots+ | 14.688 | 2.368 | 6.20× |
| chain_1000x16_L2 | cdnots | 469.234 | 38.259 | 12.26× |
| chain_1000x16_L2 | cdnots+ | 29.224 | 3.361 | 8.70× |
| nonstationary_L1 | cdnots | 0.125 | 0.051 | 2.47× |
| nonstationary_L1 | cdnots+ | 6.237 | 6.325 | 0.99× |

The nonstationary CDNOTS+ case remains around 6.3 ms (1.4% slower in this run);
covariance reuse does not accelerate its kernel orientation stage. There is no
blanket speedup claim for every workload.

### Missing-data checks

Starting from the same 1,000-row/four-variable chain, every 19th observation is
missing in one column, or in every column with different offsets. Both algorithms
use lag two. Fully affected windows take the original scalar path and return
bit-for-bit identical numeric results. Small timing differences there should not
be attributed to covariance reuse.

| Workload | Algorithm | Before (ms) | After (ms) | Speedup |
| --- | --- | ---: | ---: | ---: |
| missing_one_column | cdnots | 11.294 | 7.134 | 1.58× |
| missing_one_column | cdnots+ | 2.256 | 1.504 | 1.50× |
| missing_all_columns | cdnots | 10.361 | 8.902 | 1.16× |
| missing_all_columns | cdnots+ | 1.688 | 1.605 | 1.05× |

### CEDAR control workloads

CEDAR is unchanged and serves as a timing control.

| Workload | Algorithm | Before (ms) | After (ms) | Speedup |
| --- | --- | ---: | ---: | ---: |
| fixture_300x4_L2 | cedar | 1.182 | 1.214 | 0.97× |
| chain_1000x4_L2 | cedar | 5.000 | 4.991 | 1.00× |
| chain_5000x4_L2 | cedar | 29.955 | 30.171 | 0.99× |
| chain_1000x8_L2 | cedar | 20.126 | 19.830 | 1.01× |
| chain_1000x8_L5 | cedar | 47.965 | 47.796 | 1.00× |
| chain_1000x16_L2 | cedar | 77.959 | 76.773 | 1.02× |

## Correctness and build checks

- 100 CPU tests passed; two hardware-specific tests remain ignored.
- 89 tests passed without default/neural features.
- Strict Clippy, formatting, and release builds passed.
- Five new tests cover 480 ordered complete-data CI queries, parallel batches,
  per-test missing-row counts, singular/near-singular/constant columns, invalid
  inputs and repeated discovery over different windows.
- Every discrete field in all 24 discovery outputs matches, including graphs,
  endpoint marks, CI test counts, conditioning sets and diagnostics. Numeric
  comparison threshold: absolute error ≤1e-9; observed maximum: 2.41e-12.
- The existing batch/scalar test now allows tight floating-point tolerance
  because a cached matrix product and a scalar dot product round differently.
  Symmetry and conditioning-order equality remain exact.
- All three seeded GRACE discovery results match the original native snapshots
  exactly, including final gates and training histories. The optimized CLI's
  full CDNOTS result also matches the library result exactly.
- Each GRACE profile first verifies five instrumented Adam updates exactly
  against the public uninstrumented implementation, for every parameter.

## GRACE phase profile

Milliseconds per training step, batch 128, lag two, default basis encoder,
hidden/decoder width 64 and two hidden decoder layers. Each value is the median
of seven independent block means: reset model/optimizer state, ten warmup steps,
then 40 measured steps. Per-step timings and block ranges are in the raw files.

| Workload | Implementation | Forward | Loss | Backward | Adam | Other | Total |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| fixture_300x4_L2 | rust | 1.821 | 0.014 | 4.545 | 0.192 | 0.089 | 6.664 |
| fixture_300x4_L2 | python | 0.865 | 0.174 | 1.255 | 0.713 | 0.078 | 3.094 |
| chain_1000x4_L2 | rust | 1.816 | 0.012 | 4.601 | 0.192 | 0.098 | 6.716 |
| chain_1000x4_L2 | python | 0.852 | 0.174 | 1.220 | 0.708 | 0.074 | 3.015 |
| chain_1000x8_L2 | rust | 3.546 | 0.017 | 7.241 | 0.377 | 0.065 | 11.245 |
| chain_1000x8_L2 | python | 1.424 | 0.178 | 2.173 | 1.176 | 0.103 | 5.062 |

The separately reported total is the median of whole-step block means; it need
not equal the sum of independently computed stage medians.

![GRACE forward, loss, backward, Adam and other time](grace-phases.png)

Rust backward is 3.3–3.8× slower than upstream PyTorch in these shapes; forward
is 2.1–2.5× slower. Rust Adam is already 3.1–3.7× faster. Prioritize operator and
allocation profiling within Candle backward, then forward. These timers locate
the expensive phase; they do not yet identify the specific tensor operator.
An Adam rewrite is not supported as the next optimization by these results.

The profiling example includes the unchanged production model source. Its
timer-only Adam method is generated directly from the production body, separating
`loss.backward()` from moment and parameter updates. Source hashes and the
generation check are retained. There is no alternate optimized GRACE algorithm
hidden in the profiler.

Python receives the exact initial Rust weights, batch tensor, skeleton and
regularization settings. Native RNG streams differ, so later training states
can diverge. Forward includes normal random gate sampling; loss includes scalar
checks and Python's normal RMSE calculation. Other time includes cleanup and
Python gradient reset. The profile excludes CI discovery, input preparation,
batch selection, Lightning orchestration, validation and output. It is a model
training profile, not an end-to-end discovery speedup measurement.

## Artifacts

- [Reproduction instructions](REPRODUCE.md)
- [ParCorr summary CSV](parcorr-summary.csv) and [JSON with raw timing samples](parcorr-summary.json)
- [GRACE phase summary CSV](grace-summary.csv) and [JSON with block means](grace-summary.json)
- [GRACE figure SVG](grace-phases.svg)
- [Delivery verification](delivery-verification.json)
- [Source changes](source-changes.json) and [reviewable patch](changes.patch)
- Raw discovery outputs: `parcorr-results/`; raw phase profiles and shared inputs: `grace-results/`.

Measurements cover this CPU and these data/configurations. They do not establish
GPU performance or universal numerical equivalence at decision thresholds.
