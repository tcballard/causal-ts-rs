#[path = "support/allocations.rs"]
mod allocations;

#[global_allocator]
static ALLOCATOR: allocations::CountingAllocator = allocations::CountingAllocator;

use causal_ts::{CiEngine, ConditionalIndependence, TimeSeries};
use rand::{Rng, SeedableRng};
use rand_chacha::ChaCha8Rng;
use serde_json::json;
use std::{hint::black_box, time::Instant};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    rayon::ThreadPoolBuilder::new()
        .num_threads(1)
        .build_global()?;
    let args: Vec<_> = std::env::args().collect();
    let mode = args.get(1).map(String::as_str).unwrap_or("batch");
    let pattern = args.get(2).map(String::as_str).unwrap_or("two");
    let runs: usize = args.get(3).map(String::as_str).unwrap_or("21").parse()?;
    let mut rng = ChaCha8Rng::seed_from_u64(42);
    let mut columns: Vec<Vec<f64>> = (0..1024)
        .map(|_| (0..512).map(|_| rng.gen_range(-1.0..1.0)).collect())
        .collect();
    columns[511] = columns[511]
        .iter()
        .zip(&columns[7])
        .map(|(y, x)| y + 0.7 * x)
        .collect();
    columns[1023] = columns[1023]
        .iter()
        .zip(&columns[511])
        .map(|(z, y)| z + 0.4 * y)
        .collect();
    let data = TimeSeries::new((0..1024).map(|i| format!("x{i}")).collect(), columns)?;
    let patterns = [(7, 511, vec![1023]), (1023, 7, vec![])];
    let queries: Vec<_> = match pattern {
        "two" => patterns.to_vec(),
        "repeated" => patterns.iter().cycle().take(128).cloned().collect(),
        "disjoint" => (0..32)
            .map(|i| (3 * i, 3 * i + 1, vec![3 * i + 2]))
            .collect(),
        _ => return Err("unknown pattern".into()),
    };
    let ci = CiEngine::default();
    let selected = [
        data.column(7).to_vec(),
        data.column(511).to_vec(),
        data.column(1023).to_vec(),
    ];
    let local = [(0, 1, vec![2]), (2, 0, vec![])];
    let run = || -> causal_ts::Result<Vec<causal_ts::CiResult>> {
        match mode {
            "batch" => ci.batch_test(&data, &queries),
            "scalar" => queries
                .iter()
                .map(|(x, y, z)| ci.test_indices(&data, *x, *y, z))
                .collect(),
            "selected" if pattern != "disjoint" => {
                let prepared = ci.prepare(&selected).unwrap();
                local
                    .iter()
                    .cycle()
                    .take(queries.len())
                    .map(|(x, y, z)| prepared.test_indices(*x, *y, z))
                    .collect()
            }
            _ => Err(causal_ts::Error::InvalidConfig("unknown mode".into())),
        }
    };
    for _ in 0..3 {
        black_box(run()?);
    }
    let mut times_ms = vec![];
    for _ in 0..runs {
        let start = Instant::now();
        let output = black_box(run()?);
        times_ms.push(start.elapsed().as_secs_f64() * 1000.0);
        drop(output);
    }
    allocations::start();
    let result = run()?;
    let (allocation_calls, allocated_bytes) = allocations::stop();
    println!(
        "{}",
        json!({"mode": mode, "pattern": pattern, "rows": 512, "columns": 1024,
        "query_count": queries.len(), "times_ms": times_ms, "allocation_calls": allocation_calls,
        "allocated_bytes": allocated_bytes, "result": result})
    );
    Ok(())
}
