use candle_core::{Device, Tensor, Var};
use causal_ts::grace::model::{uniform_noise, Adam, GatedModel, ModelConfig, TensorData};
use rand::SeedableRng;
use rand_chacha::ChaCha8Rng;
use serde_json::{json, Value};
use std::fs::File;

fn data(tensor: &Tensor) -> candle_core::Result<TensorData> {
    Ok(TensorData {
        shape: tensor.dims().to_vec(),
        values: tensor.flatten_all()?.to_vec1::<f32>()?,
    })
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    rayon::ThreadPoolBuilder::new()
        .num_threads(1)
        .build_global()?;
    let mut fixtures = vec![];
    for filename in std::env::args().skip(1) {
        let shared: Value = serde_json::from_reader(File::open(&filename)?)?;
        let d = shared["num_vars"].as_u64().unwrap() as usize;
        let lag = shared["max_lag"].as_u64().unwrap() as usize;
        let config: ModelConfig = serde_json::from_value(shared["config"].clone())?;
        let skeleton: Vec<Vec<Vec<u8>>> = serde_json::from_value(shared["skeleton"].clone())?;
        let lambda = shared["lambda"].as_f64().unwrap();
        let steps_per_epoch = shared["steps_per_epoch"].as_u64().unwrap() as usize;
        let input: TensorData = serde_json::from_value(shared["input"].clone())?;
        for (batch, strided) in [(1, false), (13, true), (128, false)] {
            let mut model = GatedModel::new(d, lag, &config, &Device::Cpu, 42)?;
            model.initialize_skeleton(&skeleton, true)?;
            model.load_state(&serde_json::from_value(shared["state"].clone())?)?;
            let x = Tensor::from_vec(input.values.clone(), input.shape.clone(), &Device::Cpu)?
                .narrow(0, 0, batch)?;
            let input_var = Var::from_tensor(&x)?;
            let input_view = if strided {
                input_var
                    .as_tensor()
                    .transpose(0, 1)?
                    .contiguous()?
                    .transpose(0, 1)?
            } else {
                input_var.as_tensor().clone()
            };
            let x = &input_view;
            assert_eq!(x.is_contiguous(), !strided);
            let initial_state = model.state()?;
            let mut rng = ChaCha8Rng::seed_from_u64(904);
            let mut optimizer = Adam::new();
            let mut steps = vec![];
            for _ in 0..2 {
                let u = uniform_noise(d, lag + 1, &mut rng, &Device::Cpu)?;
                let (mu, sigma) = model.forward(x, Some(&u))?;
                let loss = model.loss(x, &mu, &sigma, lambda, steps_per_epoch, true)?;
                let gradients = model.gradients(&loss)?;
                let all_gradients = loss.backward()?;
                let input_gradient = data(all_gradients.get(input_var.as_tensor()).unwrap())?;
                let loss_value = loss.to_scalar::<f32>()?;
                optimizer.step(&model, &loss)?;
                steps.push(json!({"uniforms": data(&u)?, "mu": data(&mu)?, "sigma": data(&sigma)?, "loss": loss_value,
                    "gradients": gradients, "input_gradient": input_gradient, "after_adam": model.state()?}));
            }
            fixtures.push(json!({"name": format!("d{d}_batch{batch}_strided{strided}"), "num_vars": d, "max_lag": lag,
                "config": config, "skeleton": skeleton, "lambda": lambda, "steps_per_epoch": steps_per_epoch,
                "input": data(x)?, "strided": strided, "state": initial_state, "steps": steps}));
        }
    }
    println!("{}", json!(fixtures));
    Ok(())
}
