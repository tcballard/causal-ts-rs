#![cfg(feature = "neural")]
use candle_core::{Device, Tensor, Var};
use causal_ts::grace::model::{Adam, GatedModel, ModelConfig, TensorData};
use causal_ts::Result;
use serde::Deserialize;
use std::collections::BTreeMap;

#[derive(Deserialize)]
struct Step {
    uniforms: TensorData,
    mu: TensorData,
    sigma: TensorData,
    loss: f32,
    gradients: BTreeMap<String, TensorData>,
    input_gradient: TensorData,
    after_adam: BTreeMap<String, TensorData>,
}

#[derive(Deserialize)]
struct Fixture {
    name: String,
    num_vars: usize,
    max_lag: usize,
    config: ModelConfig,
    skeleton: Vec<Vec<Vec<u8>>>,
    lambda: f64,
    steps_per_epoch: usize,
    input: TensorData,
    strided: bool,
    state: BTreeMap<String, TensorData>,
    steps: Vec<Step>,
}

fn tensor(data: &TensorData) -> candle_core::Result<Tensor> {
    Tensor::from_vec(data.values.clone(), data.shape.clone(), &Device::Cpu)
}

fn close(actual: &Tensor, expected: &TensorData, atol: f32, label: &str) -> Result<f32> {
    assert_eq!(actual.dims(), expected.shape, "{label}");
    let values = actual.flatten_all()?.to_vec1::<f32>()?;
    let mut max_error = 0f32;
    for (i, (actual, expected)) in values.iter().zip(&expected.values).enumerate() {
        let error = (actual - expected).abs();
        assert!(
            error <= atol + 2e-5 * expected.abs(),
            "{label}[{i}]: {actual} != {expected}"
        );
        max_error = max_error.max(error);
    }
    Ok(max_error)
}

fn check(d: usize) -> Result<()> {
    let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("tests/fixtures/grace_batch_reference.json");
    let fixtures: Vec<Fixture> = serde_json::from_reader(std::fs::File::open(path)?)?;
    for fixture in fixtures.into_iter().filter(|f| f.num_vars == d) {
        let mut model = GatedModel::new(d, fixture.max_lag, &fixture.config, &Device::Cpu, 42)?;
        model.initialize_skeleton(&fixture.skeleton, true)?;
        model.load_state(&fixture.state)?;
        let input_var = Var::from_tensor(&tensor(&fixture.input)?)?;
        let input = if fixture.strided {
            input_var
                .as_tensor()
                .transpose(0, 1)?
                .contiguous()?
                .transpose(0, 1)?
        } else {
            input_var.as_tensor().clone()
        };
        let x = &input;
        assert_eq!(x.is_contiguous(), !fixture.strided);
        let mut optimizer = Adam::new();
        let mut maxima = [0f32; 4];
        for step in fixture.steps {
            let u = tensor(&step.uniforms)?;
            let (mu, sigma) = model.forward(x, Some(&u))?;
            maxima[0] = maxima[0].max(close(&mu, &step.mu, 2e-5, "mu")?).max(close(
                &sigma,
                &step.sigma,
                2e-5,
                "sigma",
            )?);
            let loss = model.loss(
                x,
                &mu,
                &sigma,
                fixture.lambda,
                fixture.steps_per_epoch,
                true,
            )?;
            let loss_error = (loss.to_scalar::<f32>()? - step.loss).abs();
            assert!(loss_error <= 2e-5 + 2e-5 * step.loss.abs());
            maxima[1] = maxima[1].max(loss_error);
            for (name, gradient) in model.gradients(&loss)? {
                maxima[2] = maxima[2].max(close(
                    &tensor(&gradient)?,
                    &step.gradients[&name],
                    5e-5,
                    &name,
                )?);
            }
            let gradients = loss.backward()?;
            maxima[2] = maxima[2].max(close(
                gradients.get(input_var.as_tensor()).unwrap(),
                &step.input_gradient,
                5e-5,
                "input gradient",
            )?);
            optimizer.step(&model, &loss)?;
            for (name, parameter) in model.state()? {
                maxima[3] = maxima[3].max(close(
                    &tensor(&parameter)?,
                    &step.after_adam[&name],
                    2e-5,
                    &name,
                )?);
            }
        }
        println!(
            "{} max_abs_prediction_loss_gradient_update={maxima:?}",
            fixture.name
        );
    }
    Ok(())
}

#[test]
fn four_variable_batches_match_original_predictions_gradients_and_updates() -> Result<()> {
    check(4)
}

#[test]
fn eight_variable_batches_match_original_predictions_gradients_and_updates() -> Result<()> {
    check(8)
}
